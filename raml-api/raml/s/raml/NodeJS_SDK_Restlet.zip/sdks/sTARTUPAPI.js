'use strict';

var util = require('util');
var restletUtils = require('../restletUtils');
var securityUtils = require('../securityUtils');

/**
 * @class STARTUPAPI
 * @param {string} [endpoint] - The API endpoint
 */
function STARTUPAPI(endpoint) {
  if (restletUtils.isDefined(endpoint) && (!restletUtils.isString(endpoint) || restletUtils.isString(endpoint) && endpoint.length === 0)) {
    throw new Error('endpoint parameter must be a non-empty string.');
  }

  this.globalSecurity = {};
  this.securityConfigurations = {};
  this.endpoint = restletUtils.stripTrailingSlash(endpoint || 'http://api.startupsass.com');
}

/**
 * Sets up the authentication to be performed through API token
 *
 * @method
 * @name STARTUPAPI#setApiToken
 * @param {string} tokenName - the name of the query parameter or header based on the location parameter.
 * @param {string} tokenValue - the value of the token
 * @param {string} location - the location of the token, either 'HEADER' or 'QUERY'.
 * If undefined it defaults to 'header'.
 */
STARTUPAPI.prototype.configureGlobalApiToken = function(tokenName, tokenValue, location) {
  if (restletUtils.isUndefined(location)) {
    util.log('No location defined, it defaults to \'HEADER\'');
    location = 'HEADER';
  }

  if (location.toUpperCase() !== 'HEADER' && location.toUpperCase() !== 'QUERY') {
    throw new Error('Unknown location: ' + location);
  }

  this.globalSecurity = {
    type: 'API_KEY',
    placement: location.toUpperCase(),
    name: tokenName,
    token: tokenValue
  };
};

/**
 * Sets up the authentication to be performed through oAuth2 protocol
 * meaning that the Authorization header will contain a Bearer token.
 *
 * @method
 * @param token - the oAuth token to use
 */
STARTUPAPI.prototype.configureGlobalOAuth2Token = function (token) {
  this.globalSecurity = {
    type: 'OAUTH2',
    token: 'Bearer ' + token
  };
};

/**
 * Sets up the authentication to be performed through basic auth.
 *
 * @method
 * @name STARTUPAPI#setBasicAuth
 * @param {string} username - the user's username
 * @param {string} key - the user's key or password
 */
STARTUPAPI.prototype.configureGlobalBasicAuthentication = function(username, key) {
  this.globalSecurity = {
    type: 'BASIC',
    token: 'Basic ' + new Buffer(username + ':' + key).toString('base64')
  };
};


/**
 * 
 * @method
 * @name STARTUPAPI#getTopicsField_selectors
 * @param {string} field_selectors - REQUIRED - 很多资源允许你指定想要返回的字段。我们称这种语法结构为字段选择器。通过准确的指出你需要的信息，我们可以优化返回结果花费的时间。
这样也能减少传输的数据。这两点让我们的APIs快速且高效，这是任何一个web应用程序的关键点，对于其他任何依赖外部API的人来说更是如此。

Example
--------
如果想要获得people先关的id,first-name,last-name,industry可以这样使用:
  `http://api.startupsass.com/v1/people/~:(id,first-name,last-name,industry)`

或者:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,industry)`

字段选择器可以选择成员对象中的字段:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,positions:(title))`

 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {string} config.queryParameters.keywords
 * @param {long} config.queryParameters.count - Maximum
 * @param {long} config.queryParameters.start - The offset by which to start Network Update pagination
 * @param {string} config.queryParameters.sign - 经过校验后生成值

 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{ }
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.getTopicsField_selectors = function(field_selectors, config, callback) {
  restletUtils.checkPathVariables(field_selectors, 'field_selectors');

  restletUtils.executeRequest.call(this, 'GET',
    this.endpoint + '/topics/~' + field_selectors + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations)
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#postTopicsField_selectors
 * @param {string} field_selectors - REQUIRED - 很多资源允许你指定想要返回的字段。我们称这种语法结构为字段选择器。通过准确的指出你需要的信息，我们可以优化返回结果花费的时间。
这样也能减少传输的数据。这两点让我们的APIs快速且高效，这是任何一个web应用程序的关键点，对于其他任何依赖外部API的人来说更是如此。

Example
--------
如果想要获得people先关的id,first-name,last-name,industry可以这样使用:
  `http://api.startupsass.com/v1/people/~:(id,first-name,last-name,industry)`

或者:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,industry)`

字段选择器可以选择成员对象中的字段:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,positions:(title))`

 * @param {object} body - the payload; is of type: topic; has the following structure:
{
  "desc" : "sample desc",
  "id" : "sample id",
  "image" : "sample image",
  "status" : "sample status",
  "title" : "sample title"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - ok - Payload :
{
  "result" : {
    "updateResultEnum" : false
  },
  "updateObjectId" : 1,
  "updateTime" : "sample updateTime"
}
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.postTopicsField_selectors = function(field_selectors, body, config, callback) {
  restletUtils.checkPathVariables(field_selectors, 'field_selectors');

  restletUtils.executeRequest.call(this, 'POST',
    this.endpoint + '/topics/~' + field_selectors + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#getTopicsTopic_idPostsfield_selectors
 * @param {string} field_selectors - REQUIRED - 很多资源允许你指定想要返回的字段。我们称这种语法结构为字段选择器。通过准确的指出你需要的信息，我们可以优化返回结果花费的时间。
这样也能减少传输的数据。这两点让我们的APIs快速且高效，这是任何一个web应用程序的关键点，对于其他任何依赖外部API的人来说更是如此。

Example
--------
如果想要获得people先关的id,first-name,last-name,industry可以这样使用:
  `http://api.startupsass.com/v1/people/~:(id,first-name,last-name,industry)`

或者:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,industry)`

字段选择器可以选择成员对象中的字段:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,positions:(title))`

 * @param {string} topic_id - REQUIRED
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {long} config.queryParameters.count - Maximum
 * @param {long} config.queryParameters.start - The offset by which to start Network Update pagination
 * @param {string} config.queryParameters.sign - 经过校验后生成值

 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{ }
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.getTopicsTopic_idPostsfield_selectors = function(field_selectors, topic_id, config, callback) {
  restletUtils.checkPathVariables(field_selectors, 'field_selectors', topic_id, 'topic_id');

  restletUtils.executeRequest.call(this, 'GET',
    this.endpoint + '/topics/' + topic_id + '/~/posts' + field_selectors + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations)
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#postTopicsTopic_idFollow
 * @param {string} topic_id - REQUIRED
 * @param {object} body - the payload; is of type: follow; has the following structure:
{
  "topicId" : 1
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{
  "result" : {
    "updateResultEnum" : false
  },
  "updateObjectId" : 1,
  "updateTime" : "sample updateTime"
}
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.postTopicsTopic_idFollow = function(topic_id, body, config, callback) {
  restletUtils.checkPathVariables(topic_id, 'topic_id');

  restletUtils.executeRequest.call(this, 'POST',
    this.endpoint + '/topics/' + topic_id + '/~/follow',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#getTopicsTopic_id
 * @param {string} topic_id - REQUIRED
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {string} config.queryParameters.sign - 经过校验后生成值

 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{
  "desc" : "sample desc",
  "id" : "sample id",
  "image" : "sample image",
  "status" : "sample status",
  "title" : "sample title"
}
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.getTopicsTopic_id = function(topic_id, config, callback) {
  restletUtils.checkPathVariables(topic_id, 'topic_id');

  restletUtils.executeRequest.call(this, 'GET',
    this.endpoint + '/topics/' + topic_id + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations)
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#putTopicsTopic_id
 * @param {string} topic_id - REQUIRED
 * @param {object} body - the payload; is of type: topic; has the following structure:
{
  "desc" : "sample desc",
  "id" : "sample id",
  "image" : "sample image",
  "status" : "sample status",
  "title" : "sample title"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.putTopicsTopic_id = function(topic_id, body, config, callback) {
  restletUtils.checkPathVariables(topic_id, 'topic_id');

  restletUtils.executeRequest.call(this, 'PUT',
    this.endpoint + '/topics/' + topic_id + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#patchTopicsTopic_id
 * @param {string} topic_id - REQUIRED
 * @param {object} body - the payload; is of type: topic; has the following structure:
{
  "desc" : "sample desc",
  "id" : "sample id",
  "image" : "sample image",
  "status" : "sample status",
  "title" : "sample title"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.patchTopicsTopic_id = function(topic_id, body, config, callback) {
  restletUtils.checkPathVariables(topic_id, 'topic_id');

  restletUtils.executeRequest.call(this, 'PATCH',
    this.endpoint + '/topics/' + topic_id + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#getPostsField_selectors
 * @param {string} field_selectors - REQUIRED - 很多资源允许你指定想要返回的字段。我们称这种语法结构为字段选择器。通过准确的指出你需要的信息，我们可以优化返回结果花费的时间。
这样也能减少传输的数据。这两点让我们的APIs快速且高效，这是任何一个web应用程序的关键点，对于其他任何依赖外部API的人来说更是如此。

Example
--------
如果想要获得people先关的id,first-name,last-name,industry可以这样使用:
  `http://api.startupsass.com/v1/people/~:(id,first-name,last-name,industry)`

或者:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,industry)`

字段选择器可以选择成员对象中的字段:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,positions:(title))`

 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {string} config.queryParameters.keywords
 * @param {long} config.queryParameters.count - Maximum
 * @param {long} config.queryParameters.start - The offset by which to start Network Update pagination
 * @param {string} config.queryParameters.sign - 经过校验后生成值

 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{ }
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.getPostsField_selectors = function(field_selectors, config, callback) {
  restletUtils.checkPathVariables(field_selectors, 'field_selectors');

  restletUtils.executeRequest.call(this, 'GET',
    this.endpoint + '/posts/~' + field_selectors + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations)
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#postPostsField_selectors
 * @param {string} field_selectors - REQUIRED - 很多资源允许你指定想要返回的字段。我们称这种语法结构为字段选择器。通过准确的指出你需要的信息，我们可以优化返回结果花费的时间。
这样也能减少传输的数据。这两点让我们的APIs快速且高效，这是任何一个web应用程序的关键点，对于其他任何依赖外部API的人来说更是如此。

Example
--------
如果想要获得people先关的id,first-name,last-name,industry可以这样使用:
  `http://api.startupsass.com/v1/people/~:(id,first-name,last-name,industry)`

或者:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,industry)`

字段选择器可以选择成员对象中的字段:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,positions:(title))`

 * @param {object} body - the payload; is of type: post; has the following structure:
{
  "createTime" : "sample createTime",
  "id" : "sample id",
  "status" : "sample status"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{
  "result" : {
    "updateResultEnum" : false
  },
  "updateObjectId" : 1,
  "updateTime" : "sample updateTime"
}
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.postPostsField_selectors = function(field_selectors, body, config, callback) {
  restletUtils.checkPathVariables(field_selectors, 'field_selectors');

  restletUtils.executeRequest.call(this, 'POST',
    this.endpoint + '/posts/~' + field_selectors + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#postPostsPostIdLike
 * @param {string} postId - REQUIRED
 * @param {object} body - the payload; is of type: like-update; has the following structure:
{
  "action" : { },
  "postId" : 1
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{
  "result" : {
    "updateResultEnum" : false
  },
  "updateObjectId" : 1,
  "updateTime" : "sample updateTime"
}
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.postPostsPostIdLike = function(postId, body, config, callback) {
  restletUtils.checkPathVariables(postId, 'postId');

  restletUtils.executeRequest.call(this, 'POST',
    this.endpoint + '/posts/' + postId + '/~/like',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#postPostsPostIdReview
 * @param {string} postId - REQUIRED
 * @param {object} body - the payload; is of type: content; has the following structure:
{
  "title" : "sample title"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.postPostsPostIdReview = function(postId, body, config, callback) {
  restletUtils.checkPathVariables(postId, 'postId');

  restletUtils.executeRequest.call(this, 'POST',
    this.endpoint + '/posts/' + postId + '/~/review',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#getPostsPostId
 * @param {string} postId - REQUIRED
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {string} config.queryParameters.sign - 经过校验后生成值

 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *    - Status code : 200 - 请求成功
 - Payload :
{
  "createTime" : "sample createTime",
  "id" : "sample id",
  "status" : "sample status"
}
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.getPostsPostId = function(postId, config, callback) {
  restletUtils.checkPathVariables(postId, 'postId');

  restletUtils.executeRequest.call(this, 'GET',
    this.endpoint + '/posts/' + postId + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations)
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#putPostsPostId
 * @param {string} postId - REQUIRED
 * @param {object} body - the payload; is of type: post; has the following structure:
{
  "createTime" : "sample createTime",
  "id" : "sample id",
  "status" : "sample status"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.putPostsPostId = function(postId, body, config, callback) {
  restletUtils.checkPathVariables(postId, 'postId');

  restletUtils.executeRequest.call(this, 'PUT',
    this.endpoint + '/posts/' + postId + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

/**
 * 
 * @method
 * @name STARTUPAPI#patchPostsPostId
 * @param {string} postId - REQUIRED
 * @param {object} body - the payload; is of type: post; has the following structure:
{
  "createTime" : "sample createTime",
  "id" : "sample id",
  "status" : "sample status"
}
 * @param {object} config - the configuration object containing the query parameters and additional headers.
 * @param {object} config.headers - headers to use for the request in addition to the default ones.
 * @param {object} config.queryParameters - query parameters to use for the request in addition to the default ones.
 * @param {Function} callback - the callback called after request completion with the following parameters:
 *  - error if any technical error occured or if the response's status does not belong to the 2xx range. In that case the error would have the following structure:
{
  status : 400,
  message : 'The request cannot be fulfilled due to XXX'
}
 *  - body of the response auto-extracted from the response if the status is in the 2xx range.
 *  - response the technical (low-level) node response (c.f. https://nodejs.org/api/http.html#http_http_incomingmessage)
 */
STARTUPAPI.prototype.patchPostsPostId = function(postId, body, config, callback) {
  restletUtils.checkPathVariables(postId, 'postId');

  restletUtils.executeRequest.call(this, 'PATCH',
    this.endpoint + '/posts/' + postId + '',
    callback,
    securityUtils.addSecurityConfiguration(config, this.globalSecurity, this.securityConfigurations),
    body
  );
};

module.exports = STARTUPAPI;
