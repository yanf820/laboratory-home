'use strict';

var STARTUPAPI = require('./sdks/sTARTUPAPI');
var restletUtils = require('./restletUtils');

module.exports = {
  STARTUPAPI : STARTUPAPI,
  restletUtils: restletUtils
};