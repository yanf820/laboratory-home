#import "ASKSdk.h"

@implementation ASKSdk

+ (ASKSTARTUPAPISdk *)sTARTUPAPISdk {
    return [ASKSTARTUPAPISdk sdk];
}

+ (ASKSTARTUPAPISdk *)sTARTUPAPISdkWithConfig:(ASKSTARTUPAPIConfig *)aConfig {
    return [ASKSTARTUPAPISdk sdkWithConfig:aConfig];
}


@end
