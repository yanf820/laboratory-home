#import <Foundation/Foundation.h>
#import "AFNetworking.h"

typedef void(^AddCredentialsBeforeRequestingOAuth2Tokens)(AFHTTPRequestOperationManager *manager);
typedef BOOL(^IsAccessTokenExpiredOnRequestError)(NSError *error, AFHTTPRequestOperation *operation);

@interface ASKSecurityConfig : NSObject

@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *placement;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *value;

@property (nonatomic, copy) NSString *schemeKey;

@property (nonatomic, copy) NSString *oauth2Grant;

@property (nonatomic, copy) NSString *oauth2AccessToken;
@property (nonatomic, copy) NSString *oauth2TokenType;

@property (nonatomic, copy) NSString *oauth2RefreshToken;
@property (nonatomic, copy) NSString *oauth2TokenURL;

@property (nonatomic, copy) NSString *oauth2ExpiresIn;
@property (nonatomic, copy) NSDate *oauth2ExpirationDate;

@property (nonatomic, copy) NSString *oauth2ClientId;
@property (nonatomic, copy) NSString *oauth2ClientSecret;

@property (nonatomic, copy) NSString *oauth2ClientIdName;
@property (nonatomic, copy) NSString *oauth2ClientSecretName;

@property (nonatomic, copy) NSString *oauth2Scope;
@property (nonatomic, copy) NSString *oauth2State;

@property (nonatomic, copy) NSString *oauth2AuthorizationURL;
@property (nonatomic, copy) NSString *oauth2RedirectURI;

@property (nonatomic, copy) NSString *oauth2Username;
@property (nonatomic, copy) NSString *oauth2Password;

@property (nonatomic, assign) BOOL allowSelfSignedCertificates;

@property (nonatomic, assign) BOOL oauth2ShouldPassAccessTokenAsQueryParameter;
@property (nonatomic, assign) BOOL oauth2ShouldHandleRefreshTokenAutomatically;

@property (nonatomic, copy) AddCredentialsBeforeRequestingOAuth2Tokens addCredentialsBeforeRequestingOAuth2Tokens;
@property (nonatomic, copy) IsAccessTokenExpiredOnRequestError isAccessTokenExpiredOnRequestError;

+ (instancetype)securityConfig;

@end