#import "AFHTTPRequestOperationManager.h"

@interface ASKRequestHelper : NSObject

+ (AFHTTPRequestOperationManager *)configureBasicAuthorizationWithUsername:(NSString *)username andPassword:(NSString *)password;
+ (AFHTTPRequestOperationManager *)configureHeaderApiKeyAuthorizationWithToken:(NSString *)token andHeaderName:(NSString *)headerName;
+ (AFHTTPRequestOperationManager *)configureOAuth2AuthorizationWithToken:(NSString *)token;

@end