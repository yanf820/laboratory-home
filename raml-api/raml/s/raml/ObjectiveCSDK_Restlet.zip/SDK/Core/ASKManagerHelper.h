#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "ASKSecurityConfig.h"

@interface ASKManagerHelper : NSObject

+(void)updateManager:(AFHTTPRequestOperationManager *)manager
  withSecurityConfig:(ASKSecurityConfig *)securityConfig;

@end
