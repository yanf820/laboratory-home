#import <Foundation/Foundation.h>

#import "ASKSecurityConfig.h"

@interface ASKSecurityHelper : NSObject


#pragma mark - helpers to build a full securityConfig for a specified security scheme

+ (ASKSecurityConfig *)getConfigBasicWithUsername:(NSString *)username
                                     andPassword:(NSString *)password
                                    andSchemeKey:(NSString *)schemeKey;

+ (ASKSecurityConfig *)getConfigApiTokenAsQueryParameterWithName:(NSString *)name
                                                       andValue:(NSString *)value
                                                   andSchemeKey:(NSString *)schemeKey;

+ (ASKSecurityConfig *)getConfigApiTokenAsHeaderWithName:(NSString *)name
                                               andValue:(NSString *)value
                                           andSchemeKey:(NSString *)schemeKey;

+ (ASKSecurityConfig *)getConfigOAuth2ForImplicitWithAccessToken:(NSString *)accessToken
                                                   andSchemeKey:(NSString *)schemeKey;

+ (ASKSecurityConfig *)getConfigOAuth2ForPasswordWithAccessToken:(NSString *)accessToken
                                                andRefreshToken:(NSString *)refreshToken
                                                    andClientId:(NSString *)clientId
                                                andClientSecret:(NSString *)clientSecret
                                             andRefreshTokenURL:(NSString *)refreshTokenURL
                                                   andSchemeKey:(NSString *)schemeKey;

#pragma mark - helpers to init a securityConfig for a specified security scheme

+ (ASKSecurityConfig *)initOAuth2ForImplicitForSchemeKey:(NSString *)schemeKey;
+ (ASKSecurityConfig *)initOAuth2ForPasswordForSchemeKey:(NSString *)schemeKey;
+ (ASKSecurityConfig *)initOAuth2ForAccessCodeForSchemeKey:(NSString *)schemeKey;
+ (ASKSecurityConfig *)initOAuth2ForApplicationForSchemeKey:(NSString *)schemeKey;

#pragma mark - helpers to complete a securityConfig

+ (void)setOAuth2AccessToken:(NSString *)accessToken
            toSecurityConfig:(ASKSecurityConfig *)securityConfig;

+ (void)setOAuth2ExpiresIn:(NSString *)expiresIn
          toSecurityConfig:(ASKSecurityConfig *)securityConfig;

+ (NSString *)encodeBase64Username:(NSString *)username
                       andPassword:(NSString *)password;

+(void)addOptionalEntryForKey:(NSString *)key andValue:(NSString *)value inDictionary:(NSMutableDictionary *)dictionary;

@end
