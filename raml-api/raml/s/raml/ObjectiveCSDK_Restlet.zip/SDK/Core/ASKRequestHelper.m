#import <Foundation/Foundation.h>
#import "ASKRequestHelper.h"

@implementation ASKRequestHelper

+ (AFHTTPRequestOperationManager *)configureBasicAuthorizationWithUsername:(NSString *)username andPassword:(NSString *)password {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

    NSString *usernameAndPassword = [NSString stringWithFormat:@"%@:%@", username, password];
    
    NSData *usernameAndPasswordData = [usernameAndPassword dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *usernameAndPasswordBase64 = [usernameAndPasswordData base64EncodedStringWithOptions:0];
    
    NSString *digested = [NSString stringWithFormat:@"%@ %@", @"Basic", usernameAndPasswordBase64];
    
    AFHTTPRequestSerializer *requestSerializer = [AFHTTPRequestSerializer serializer];
    [requestSerializer setValue:digested forHTTPHeaderField:@"Authorization"];
    
    manager.requestSerializer = requestSerializer;
    
    return manager;
}

+ (AFHTTPRequestOperationManager *)configureHeaderApiKeyAuthorizationWithToken:(NSString *)token andHeaderName:(NSString *)headerName {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    AFHTTPRequestSerializer *requestSerializer = [AFHTTPRequestSerializer serializer];
    [requestSerializer setValue:token forHTTPHeaderField:headerName];
    
    manager.requestSerializer = requestSerializer;
    
    return manager;
}

+ (AFHTTPRequestOperationManager *)configureOAuth2AuthorizationWithToken:(NSString *)token {
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSString *formattedToken = [NSString stringWithFormat:@"%@ %@", @"Bearer", token];
    
    AFHTTPRequestSerializer *requestSerializer = [AFHTTPRequestSerializer serializer];
    [requestSerializer setValue:formattedToken forHTTPHeaderField:@"Authorization"];
    
    manager.requestSerializer = requestSerializer;

    return manager;
}

@end