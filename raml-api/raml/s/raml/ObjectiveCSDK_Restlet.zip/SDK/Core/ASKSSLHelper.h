#import <Foundation/Foundation.h>
#import "AFSecurityPolicy.h"

@interface ASKSSLHelper : NSObject

+(AFSecurityPolicy *) getSecurityPolicyForSelfSignedCertificates;

@end
