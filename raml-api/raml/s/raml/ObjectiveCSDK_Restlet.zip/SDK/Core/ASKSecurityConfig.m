#import "ASKSecurityConfig.h"

@implementation ASKSecurityConfig

- (instancetype)init {
    self = [super init];
    
    if (self) {
        self.oauth2ClientIdName = @"client_id";
        self.oauth2ClientSecretName = @"client_secret";
        self.oauth2ShouldPassAccessTokenAsQueryParameter = NO;
        self.oauth2ShouldHandleRefreshTokenAutomatically = YES;
        self.allowSelfSignedCertificates = NO;
    }
    
    return self;
}

+ (instancetype)securityConfig {
    return [[self alloc] init];
}

@end