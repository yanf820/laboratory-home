#import "ASKSSLHelper.h"

@implementation ASKSSLHelper

+(AFSecurityPolicy *) getSecurityPolicyForSelfSignedCertificates {
    
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    
    [securityPolicy setValidatesDomainName:NO];
    [securityPolicy setAllowInvalidCertificates:YES];
    
    return securityPolicy;
}

@end
