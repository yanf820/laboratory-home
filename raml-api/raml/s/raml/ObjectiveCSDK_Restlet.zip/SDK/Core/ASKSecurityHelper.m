#import "ASKSecurityHelper.h"

@implementation ASKSecurityHelper

+ (ASKSecurityConfig *)getConfigBasicWithUsername:(NSString *)username
                                     andPassword:(NSString *)password
                                    andSchemeKey:(NSString *)schemeKey {
    
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    securityConfig.schemeKey = schemeKey;
    
    securityConfig.type = @"BASIC";
    securityConfig.value = [ASKSecurityHelper getDigestedForBasicWithUsername:username andPassword:password];
    
    return securityConfig;
}

+ (NSString *)getDigestedForBasicWithUsername:(NSString *)username
                                  andPassword:(NSString *)password {
    
    NSString *usernameAndPasswordBase64 = [ASKSecurityHelper encodeBase64Username:username andPassword:password];
    NSString *digested = [NSString stringWithFormat:@"%@ %@", @"Basic", usernameAndPasswordBase64];
    
    return digested;
}

+ (ASKSecurityConfig *)getConfigApiTokenAsQueryParameterWithName:(NSString *)name
                                                       andValue:(NSString *)value
                                                   andSchemeKey:(NSString *)schemeKey {
    
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    securityConfig.schemeKey = schemeKey;
    
    securityConfig.type = @"API_KEY";
    securityConfig.placement = @"QUERY";
    securityConfig.name = name;
    securityConfig.value = value;
    
    return securityConfig;
}

+ (ASKSecurityConfig *)getConfigApiTokenAsHeaderWithName:(NSString *)name
                                               andValue:(NSString *)value
                                           andSchemeKey:(NSString *)schemeKey {
    
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    securityConfig.schemeKey = schemeKey;
    
    securityConfig.type = @"API_KEY";
    securityConfig.placement = @"HEADER";
    securityConfig.name = name;
    securityConfig.value = value;
    
    return securityConfig;
}

+ (ASKSecurityConfig *)getConfigOAuth2ForImplicitWithAccessToken:(NSString *)accessToken
                                                   andSchemeKey:(NSString *)schemeKey {
    
    ASKSecurityConfig *securityConfig = [ASKSecurityHelper initOAuth2ForImplicitForSchemeKey:schemeKey];
    [ASKSecurityHelper setOAuth2AccessToken:accessToken toSecurityConfig:securityConfig];
    
    return securityConfig;
}

+ (ASKSecurityConfig *)getConfigOAuth2ForPasswordWithAccessToken:(NSString *)accessToken
                                                andRefreshToken:(NSString *)refreshToken
                                                    andClientId:(NSString *)clientId
                                                andClientSecret:(NSString *)clientSecret
                                             andRefreshTokenURL:(NSString *)refreshTokenURL
                                                   andSchemeKey:(NSString *)schemeKey {
    
    ASKSecurityConfig *securityConfig = [ASKSecurityHelper initOAuth2ForPasswordForSchemeKey:schemeKey];
    
    [ASKSecurityHelper setOAuth2AccessToken:accessToken toSecurityConfig:securityConfig];
    securityConfig.oauth2RefreshToken = refreshToken;
    
    securityConfig.oauth2ClientId = clientId;
    securityConfig.oauth2ClientSecret = clientSecret;
    
    return securityConfig;
}

#pragma mark - helpers to init a securityConfig for a specified security scheme

+ (ASKSecurityConfig *)initOAuth2ForImplicitForSchemeKey:(NSString *)schemeKey {
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    
    securityConfig.schemeKey = schemeKey;
    securityConfig.type = @"OAUTH2";
    securityConfig.oauth2Grant = @"implicit";
    
    return securityConfig;
}

+ (ASKSecurityConfig *)initOAuth2ForPasswordForSchemeKey:(NSString *)schemeKey {
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    
    securityConfig.schemeKey = schemeKey;
    securityConfig.type = @"OAUTH2";
    securityConfig.oauth2Grant = @"resourceOwnerPassword";
    
    return securityConfig;
}

+ (ASKSecurityConfig *)initOAuth2ForAccessCodeForSchemeKey:(NSString *)schemeKey {
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    
    securityConfig.schemeKey = schemeKey;
    securityConfig.type = @"OAUTH2";
    securityConfig.oauth2Grant = @"authorizationCode";
    
    return securityConfig;
}

+ (ASKSecurityConfig *)initOAuth2ForApplicationForSchemeKey:(NSString *)schemeKey {
    ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
    
    securityConfig.schemeKey = schemeKey;
    securityConfig.type = @"OAUTH2";
    securityConfig.oauth2Grant = @"clientCredentials";
    
    return securityConfig;
}

#pragma mark - helpers to complete a securityConfig

+ (void)setOAuth2AccessToken:(NSString *)accessToken
            toSecurityConfig:(ASKSecurityConfig *)securityConfig {
    
    securityConfig.value = [NSString stringWithFormat:@"Bearer %@", accessToken];
    securityConfig.oauth2AccessToken = accessToken;
    
}

+ (void)setOAuth2ExpiresIn:(NSString *)expiresIn
          toSecurityConfig:(ASKSecurityConfig *)securityConfig {
    
    securityConfig.oauth2ExpiresIn = expiresIn;
    
    securityConfig.oauth2ExpirationDate = nil;
    
    if (securityConfig.oauth2ExpiresIn) {
        
        securityConfig.oauth2ExpirationDate = [[NSDate date] dateByAddingTimeInterval:(NSTimeInterval) securityConfig.oauth2ExpiresIn.intValue];
    }
    
}

+ (NSString *)encodeBase64Username:(NSString *)username
                       andPassword:(NSString *)password {
    
    NSString *usernameAndPassword = [NSString stringWithFormat:@"%@:%@", username, password];
    
    NSData *usernameAndPasswordData = [usernameAndPassword dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *usernameAndPasswordBase64 = [usernameAndPasswordData base64EncodedStringWithOptions:0];
    
    return usernameAndPasswordBase64;
}

+(void)addOptionalEntryForKey:(NSString *)key andValue:(NSString *)value inDictionary:(NSMutableDictionary *)dictionary {
    
    if (value.length == 0) {
        return;
    }
    
    dictionary[key] = value;
}

@end