#import "ASKManagerHelper.h"
#import "ASKSSLHelper.h"

@implementation ASKManagerHelper

+(void)updateManager:(AFHTTPRequestOperationManager *)manager
  withSecurityConfig:(ASKSecurityConfig *)securityConfig {
    
    if (securityConfig.allowSelfSignedCertificates) {
        manager.securityPolicy = [ASKSSLHelper getSecurityPolicyForSelfSignedCertificates];
    }
    
}

@end
