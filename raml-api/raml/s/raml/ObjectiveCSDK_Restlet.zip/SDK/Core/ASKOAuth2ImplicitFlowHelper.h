#import <Foundation/Foundation.h>
#import "ASKSecurityConfig.h"

@interface ASKOAuth2ImplicitFlowHelper : NSObject

+(NSString *)getWebViewAuthorizationURLForConfig:(ASKSecurityConfig *)securityConfig;

+(NSString *)getWebViewAuthorizationURLForConfig:(ASKSecurityConfig *)securityConfig andAdditionalParameters:(NSDictionary *)additionalParameters;

+(NSDictionary *)getFragmentKeyValuesFromViewURL:(NSString *)viewURL;

+(void)updateSecurityConfig:(ASKSecurityConfig *)securityConfig
             fromWebViewURL:(NSString *)webViewUrl
                      error:(NSError * __autoreleasing *)outError;

@end
