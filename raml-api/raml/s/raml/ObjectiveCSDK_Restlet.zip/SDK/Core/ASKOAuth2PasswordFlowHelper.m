#import "ASKOAuth2PasswordFlowHelper.h"
#import "ASKSecurityHelper.h"
#import "ASKManagerHelper.h"

static int const STATUS_CODE_UNAUTHORIZED = 401;
static int const REQUIRED_VALUE_ERROR = 1200;

@implementation ASKOAuth2PasswordFlowHelper

+(void)fetchAccessAndRefreshTokensForConfig:(ASKSecurityConfig *)securityConfig
                                   andBlock:(void (^)(id responseObject, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    return [ASKOAuth2PasswordFlowHelper fetchAccessAndRefreshTokensForConfig:securityConfig withAdditionalParameters:nil andBlock:aBlock];
}

+(void)fetchAccessAndRefreshTokensForConfig:(ASKSecurityConfig *)securityConfig
                   withAdditionalParameters:(NSDictionary *)additionalParameters
                                   andBlock:(void (^)(id responseObject, NSError *error, AFHTTPRequestOperation *operation)) aBlock {
    
    NSMutableDictionary *postData = [NSMutableDictionary
                                     dictionaryWithDictionary:@{
                                                                @"grant_type" : @"password", // required
                                                                @"username" : securityConfig.oauth2Username, // required
                                                                @"password" : securityConfig.oauth2Password // required
                                                                }];
    
    [ASKSecurityHelper addOptionalEntryForKey:@"scope"
                                    andValue:securityConfig.oauth2Scope
                                inDictionary:postData]; // optional
    
    if ([additionalParameters count] > 0) {
        [postData addEntriesFromDictionary:additionalParameters];
    }
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];
    
    [ASKOAuth2PasswordFlowHelper addCredentialsBeforeRequestingTokensForSecurityConfig:securityConfig andPostData:postData andManager:manager];
    
    [manager POST:securityConfig.oauth2TokenURL
       parameters:postData
          success:^void(AFHTTPRequestOperation *operation, id responseObject) {
              
              [ASKOAuth2PasswordFlowHelper updateTokensOfSecurityConfig:securityConfig fromResponse:responseObject];
              
              if (aBlock) {
                  aBlock(responseObject, nil, operation);
              }
              
          }
          failure:^void(AFHTTPRequestOperation *operation, NSError *error) {
              if (aBlock) {
                  aBlock(nil, error, operation);
              }
          }];
    
}

+(void)updateTokensOfSecurityConfig:(ASKSecurityConfig *)securityConfig
                       fromResponse:(id)responseObject {
    
    NSDictionary *response = (NSDictionary *) responseObject;
    
    [ASKSecurityHelper setOAuth2AccessToken:response[@"access_token"]
                          toSecurityConfig:securityConfig]; // required
    
    securityConfig.oauth2TokenType = response[@"token_type"]; // required
    
    [ASKSecurityHelper setOAuth2ExpiresIn:response[@"expires_in"]
                        toSecurityConfig:securityConfig]; // optional
    
    securityConfig.oauth2RefreshToken = response[@"refresh_token"]; // optional
    
    NSString *scope = response[@"scope"]; // optional
    if (scope) {
        securityConfig.oauth2Scope = scope;
    }
    
}

+(void)addCredentialsBeforeRequestingTokensForSecurityConfig:(ASKSecurityConfig *)securityConfig  andPostData:(NSMutableDictionary *)postData andManager:(AFHTTPRequestOperationManager *)manager {

    if (securityConfig.addCredentialsBeforeRequestingOAuth2Tokens) {
        securityConfig.addCredentialsBeforeRequestingOAuth2Tokens(manager);
        return;
    }
    
    postData[securityConfig.oauth2ClientIdName] = securityConfig.oauth2ClientId;
    
    [ASKSecurityHelper addOptionalEntryForKey:securityConfig.oauth2ClientSecretName
                                    andValue:securityConfig.oauth2ClientSecret
                                inDictionary:postData];
    
}

+(void)requestRefreshTokenForConfig:(ASKSecurityConfig *)securityConfig
                            success:(void (^)())success
                            failure:(void (^)(NSError *error, AFHTTPRequestOperation *operation))failure{

    if (!securityConfig.oauth2RefreshToken) {

        NSString *message = @"A refresh token must be specified for the given securityConfig.";

        NSError *error = [NSError errorWithDomain:@"oauth2.resourceOwnerPasswordFlow.refresh.token"
                                             code:REQUIRED_VALUE_ERROR
                                         userInfo:@{ 
                                         		    NSLocalizedDescriptionKey: message
                                                    }];
        failure(error, nil /* operation */);
        return;
    }

    NSMutableDictionary *postData = [NSMutableDictionary
                                     dictionaryWithDictionary:@{
                                                                @"grant_type" : @"refresh_token",
                                                                @"refresh_token" : securityConfig.oauth2RefreshToken // required
                                                                }];
    
    [ASKSecurityHelper addOptionalEntryForKey:@"scope"
                                    andValue:securityConfig.oauth2Scope
                                inDictionary:postData]; // optional
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];
    
    [ASKOAuth2PasswordFlowHelper addCredentialsBeforeRequestingTokensForSecurityConfig:securityConfig andPostData:postData andManager:manager];
    
    [manager POST:securityConfig.oauth2TokenURL
       parameters:postData
          success:^void(AFHTTPRequestOperation *operation, id responseObject) {
              
              [ASKOAuth2PasswordFlowHelper updateTokensOfSecurityConfig:securityConfig fromResponse:responseObject];
              
              if(success){
                  success();
              };
          }
          failure:^void(AFHTTPRequestOperation *operation, NSError *error) {
              
              if(failure){
                  failure(error, operation);
              };
              
          }];
    
}

+(BOOL)shouldRefreshTokenForSecurityConfig:(ASKSecurityConfig *)securityConfig {
    
    if (![securityConfig.oauth2Grant isEqualToString:@"resourceOwnerPassword"]) {
        return NO;
    }
    
    if (!securityConfig.oauth2ShouldHandleRefreshTokenAutomatically) {
        return NO;
    }
    
    if (!securityConfig.oauth2ExpirationDate) {
        return NO;
    }
    
    BOOL isExpired = [[NSDate date] compare:securityConfig.oauth2ExpirationDate] == NSOrderedDescending;
    return isExpired;
}

+(void)handleRequestError:(NSError *)error
        forSecurityConfig:(ASKSecurityConfig *)securityConfig
             andOperation:(AFHTTPRequestOperation *)operation
          andFailureBlock:(void (^)(NSError *error, AFHTTPRequestOperation *operation))failureBlock
           andRepeatBlock:(void (^)())repeatBlock
{
    
    if (!securityConfig.oauth2ShouldHandleRefreshTokenAutomatically) {
        failureBlock(error, operation);
        return;
    }
    
    BOOL isTokenExpired = NO;
    
    if (securityConfig.isAccessTokenExpiredOnRequestError) {
        isTokenExpired = securityConfig.isAccessTokenExpiredOnRequestError(error, operation);
        
    } else {
        isTokenExpired = STATUS_CODE_UNAUTHORIZED == [operation.response statusCode];
        
    }
    
    if (isTokenExpired) {
        
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:repeatBlock
                                                         failure:failureBlock];
        
    } else {
        failureBlock(error, operation);
    }
    
}

@end
