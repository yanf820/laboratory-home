#import "ASKOAuth2ImplicitFlowHelper.h"
#import "ASKSecurityHelper.h"

static int const STATE_ERROR = 1100;

@implementation ASKOAuth2ImplicitFlowHelper

+(NSString *)getWebViewAuthorizationURLForConfig:(ASKSecurityConfig *)securityConfig {
    return [ASKOAuth2ImplicitFlowHelper getWebViewAuthorizationURLForConfig:securityConfig andAdditionalParameters:nil];
}

+(NSString *)getWebViewAuthorizationURLForConfig:(ASKSecurityConfig *)securityConfig andAdditionalParameters:(NSDictionary *)additionalParameters {
    
    NSMutableDictionary *queryParameters = [NSMutableDictionary
                                            dictionaryWithDictionary:@{
                                                                       @"response_type": @"token"
                                                                       }];
    
    queryParameters[securityConfig.oauth2ClientIdName] = securityConfig.oauth2ClientId; // required
    
    [ASKSecurityHelper addOptionalEntryForKey:@"redirect_uri"
                                    andValue:securityConfig.oauth2RedirectURI
                                inDictionary:queryParameters];
    
    [ASKSecurityHelper addOptionalEntryForKey:@"scope"
                                    andValue:securityConfig.oauth2Scope
                                inDictionary:queryParameters];
    
    [ASKSecurityHelper addOptionalEntryForKey:@"state"
                                    andValue:securityConfig.oauth2State
                                inDictionary:queryParameters];
    
    if ([additionalParameters count] > 0) {
        [queryParameters addEntriesFromDictionary:additionalParameters];
    }
    
    NSMutableArray *params = [NSMutableArray array];
    
    [queryParameters enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        [params addObject:[NSString stringWithFormat:@"%@=%@", key, obj]];
    }];
    
    return [NSString stringWithFormat:@"%@?%@",
            securityConfig.oauth2AuthorizationURL,
            [params componentsJoinedByString:@"&"]
            ];
}

+(NSDictionary *)getFragmentKeyValuesFromViewURL:(NSString *)viewURL {
    
    NSURLComponents *urlComponents = [NSURLComponents componentsWithString:viewURL];
    NSArray *keyValues = [urlComponents.fragment componentsSeparatedByString:@"&"];
    
    
    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    [keyValues enumerateObjectsUsingBlock:^(id obj,
                                            NSUInteger idx,
                                            BOOL *stop) {
        
        NSString *keyValue = (NSString *) obj;
        NSString *key = [keyValue componentsSeparatedByString:@"="].firstObject;
        NSString *value = [keyValue componentsSeparatedByString:@"="].lastObject;
        
        info[key] = value;
    }];
    
    return info;
}

+(void)updateSecurityConfig:(ASKSecurityConfig *)securityConfig
             fromWebViewURL:(NSString *)webViewUrl
                      error:(NSError * __autoreleasing *)outError {
    
    NSDictionary *keyValues = [ASKOAuth2ImplicitFlowHelper getFragmentKeyValuesFromViewURL:webViewUrl];
    
    // If a 'state' parameter has been sent,
    // check that it is the same that has been returned.
    //
    if (securityConfig.oauth2State
        && ![securityConfig.oauth2State isEqualToString:keyValues[@"state"]]) {
        
        NSString *message = [NSString stringWithFormat:@"Inconsistent states: sent (%@), received (%@)", securityConfig.oauth2State, keyValues[@"state"]];
        
        *outError = [NSError errorWithDomain:@"oauth2.implicitFlow.authentication.state"
                                        code:STATE_ERROR
                                    userInfo:@{ NSLocalizedDescriptionKey: message }];
        return;
    }
    
    [ASKSecurityHelper setOAuth2AccessToken:keyValues[@"access_token"]
                          toSecurityConfig:securityConfig]; // required
    
    securityConfig.oauth2TokenType = keyValues[@"token_type"]; // required
    
    [ASKSecurityHelper setOAuth2ExpiresIn:keyValues[@"expires_in"] toSecurityConfig:securityConfig]; // recommended
    
    if ([keyValues objectForKey:@"scope"]) { // optional
        securityConfig.oauth2Scope = keyValues[@"scope"];
    }
    
}

@end
