#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "ASKSecurityConfig.h"


@interface ASKOAuth2PasswordFlowHelper : NSObject

+(void)fetchAccessAndRefreshTokensForConfig:(ASKSecurityConfig *)securityConfig
                                   andBlock:(void (^)(id responseObject, NSError *error, AFHTTPRequestOperation *operation))aBlock;

+(void)fetchAccessAndRefreshTokensForConfig:(ASKSecurityConfig *)securityConfig
                   withAdditionalParameters:(NSDictionary *)additionalParameters
                                   andBlock:(void (^)(id responseObject, NSError *error, AFHTTPRequestOperation *operation))aBlock;

+(void)requestRefreshTokenForConfig:(ASKSecurityConfig *)securityConfig
                            success:(void (^)())success
                            failure:(void (^)(NSError *error, AFHTTPRequestOperation *operation))failure;

+(BOOL)shouldRefreshTokenForSecurityConfig:(ASKSecurityConfig *)securityConfig;

+(void)handleRequestError:(NSError *)error
        forSecurityConfig:(ASKSecurityConfig *)securityConfig
             andOperation:(AFHTTPRequestOperation *)operation
          andFailureBlock:(void (^)(NSError *error, AFHTTPRequestOperation *operation))failureBlock
           andRepeatBlock:(void (^)())repeatBlock;

@end
