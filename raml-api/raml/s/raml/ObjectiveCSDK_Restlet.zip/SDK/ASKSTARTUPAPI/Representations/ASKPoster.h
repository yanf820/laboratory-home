#import "ASKRepresentation.h"


@interface ASKPoster : ASKRepresentation


@property (nonatomic, strong) NSNumber * $id;

@property (nonatomic, copy) NSString * name;

@property (nonatomic, copy) NSString * image;

@property (nonatomic, copy) NSString * level;

+ (instancetype)representation;

@end