#import "ASKFans.h"

@implementation ASKFans

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"id: %@\n",self.$id];
    [result appendFormat:@"name: %@\n",self.name];
    [result appendFormat:@"image: %@\n",self.image];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"id" : _GetNullable(self.$id),
                @"name" : _GetNullable(self.name),
                @"image" : _GetNullable(self.image),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKFans *result = [self representation];
    result.$id = _Nulled(aDictionary[@"id"]);
    result.name = _Nulled(aDictionary[@"name"]);
    result.image = _Nulled(aDictionary[@"image"]);

    return result;
}

@end
