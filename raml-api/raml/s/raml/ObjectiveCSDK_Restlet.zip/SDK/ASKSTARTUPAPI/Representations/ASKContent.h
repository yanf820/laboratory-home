#import "ASKRepresentation.h"


@interface ASKContent : ASKRepresentation


@property (nonatomic, copy) NSString * title;

+ (instancetype)representation;

@end