#import "ASKUpdate.h"

@implementation ASKUpdate

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"updateObjectId: %@\n",self.updateObjectId];
    [result appendFormat:@"result: %@\n",self.result];
    [result appendFormat:@"updateTime: %@\n",self.updateTime];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"updateObjectId" : _GetNullable(self.updateObjectId),
                @"result" : _GetNullable([self.result toDictionary]),
                @"updateTime" : _GetNullable(self.updateTime),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKUpdate *result = [self representation];
    result.updateObjectId = _Nulled(aDictionary[@"updateObjectId"]);
    result.result = [ASKResult fromDictionary:_Nulled(aDictionary[@"result"])];
    result.updateTime = _Nulled(aDictionary[@"updateTime"]);

    return result;
}

@end
