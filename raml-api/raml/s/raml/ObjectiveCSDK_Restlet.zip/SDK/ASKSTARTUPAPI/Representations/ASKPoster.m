#import "ASKPoster.h"

@implementation ASKPoster

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"id: %@\n",self.$id];
    [result appendFormat:@"name: %@\n",self.name];
    [result appendFormat:@"image: %@\n",self.image];
    [result appendFormat:@"level: %@\n",self.level];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"id" : _GetNullable(self.$id),
                @"name" : _GetNullable(self.name),
                @"image" : _GetNullable(self.image),
                @"level" : _GetNullable(self.level),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKPoster *result = [self representation];
    result.$id = _Nulled(aDictionary[@"id"]);
    result.name = _Nulled(aDictionary[@"name"]);
    result.image = _Nulled(aDictionary[@"image"]);
    result.level = _Nulled(aDictionary[@"level"]);

    return result;
}

@end
