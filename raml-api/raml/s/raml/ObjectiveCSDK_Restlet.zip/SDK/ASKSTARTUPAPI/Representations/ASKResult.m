#import "ASKResult.h"

@implementation ASKResult

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"updateResultEnum: %@\n",self.updateResultEnum];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"updateResultEnum" : _GetNullable(self.updateResultEnum),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKResult *result = [self representation];
    result.updateResultEnum = _Nulled(aDictionary[@"updateResultEnum"]);

    return result;
}

@end
