#import "ASKTopic.h"

@implementation ASKTopic

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"id: %@\n",self.$id];
    [result appendFormat:@"title: %@\n",self.title];
    [result appendFormat:@"image: %@\n",self.image];
    [result appendFormat:@"desc: %@\n",self.desc];
    [result appendFormat:@"status: %@\n",self.status];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"id" : _GetNullable(self.$id),
                @"title" : _GetNullable(self.title),
                @"image" : _GetNullable(self.image),
                @"desc" : _GetNullable(self.desc),
                @"status" : _GetNullable(self.status),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKTopic *result = [self representation];
    result.$id = _Nulled(aDictionary[@"id"]);
    result.title = _Nulled(aDictionary[@"title"]);
    result.image = _Nulled(aDictionary[@"image"]);
    result.desc = _Nulled(aDictionary[@"desc"]);
    result.status = _Nulled(aDictionary[@"status"]);

    return result;
}

@end
