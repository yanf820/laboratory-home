#import "ASKRepresentation.h"


@interface ASKReviewer : ASKRepresentation


@property (nonatomic, strong) NSNumber * $id;

@property (nonatomic, copy) NSString * name;

+ (instancetype)representation;

@end