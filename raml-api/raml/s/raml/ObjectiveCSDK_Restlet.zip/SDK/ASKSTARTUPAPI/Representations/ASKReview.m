#import "ASKReview.h"

@implementation ASKReview

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"id: %@\n",self.$id];
    [result appendFormat:@"content: %@\n",self.content];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"id" : _GetNullable(self.$id),
                @"content" : _GetNullable(self.content),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKReview *result = [self representation];
    result.$id = _Nulled(aDictionary[@"id"]);
    result.content = _Nulled(aDictionary[@"content"]);

    return result;
}

@end
