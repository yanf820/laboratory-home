#import "ASKErrorschema.h"

@implementation ASKErrorschema

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"errorCode: %@\n",self.errorCode];
    [result appendFormat:@"message: %@\n",self.message];
    [result appendFormat:@"requestId: %@\n",self.requestId];
    [result appendFormat:@"status: %@\n",self.status];
    [result appendFormat:@"timestamp: %@\n",self.timestamp];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"errorCode" : _GetNullable(self.errorCode),
                @"message" : _GetNullable(self.message),
                @"requestId" : _GetNullable(self.requestId),
                @"status" : _GetNullable(self.status),
                @"timestamp" : _GetNullable(self.timestamp),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKErrorschema *result = [self representation];
    result.errorCode = _Nulled(aDictionary[@"errorCode"]);
    result.message = _Nulled(aDictionary[@"message"]);
    result.requestId = _Nulled(aDictionary[@"requestId"]);
    result.status = _Nulled(aDictionary[@"status"]);
    result.timestamp = _Nulled(aDictionary[@"timestamp"]);

    return result;
}

@end
