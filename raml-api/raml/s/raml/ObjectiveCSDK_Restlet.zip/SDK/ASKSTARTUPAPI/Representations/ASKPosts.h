#import "ASKRepresentation.h"


@interface ASKPosts : ASKRepresentation


+ (instancetype)representation;

@end