#import "ASKPost.h"

@implementation ASKPost

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"id: %@\n",self.$id];
    [result appendFormat:@"createTime: %@\n",self.createTime];
    [result appendFormat:@"status: %@\n",self.status];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"id" : _GetNullable(self.$id),
                @"createTime" : _GetNullable(self.createTime),
                @"status" : _GetNullable(self.status),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKPost *result = [self representation];
    result.$id = _Nulled(aDictionary[@"id"]);
    result.createTime = _Nulled(aDictionary[@"createTime"]);
    result.status = _Nulled(aDictionary[@"status"]);

    return result;
}

@end
