#import "ASKRepresentation.h"


@interface ASKTopic : ASKRepresentation

/** 
 ID
 */
@property (nonatomic, copy) NSString * $id;
/** 
 标题
 */
@property (nonatomic, copy) NSString * title;
/** 
 图片
 */
@property (nonatomic, copy) NSString * image;
/** 
 描述
 */
@property (nonatomic, copy) NSString * desc;
/** 
 当前状态
 */
@property (nonatomic, copy) NSString * status;

+ (instancetype)representation;

@end