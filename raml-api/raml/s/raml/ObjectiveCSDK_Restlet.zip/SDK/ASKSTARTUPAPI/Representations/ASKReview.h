#import "ASKRepresentation.h"


@interface ASKReview : ASKRepresentation


@property (nonatomic, strong) NSNumber * $id;

@property (nonatomic, copy) NSString * content;

+ (instancetype)representation;

@end