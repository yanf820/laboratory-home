#import "ASKRepresentation.h"

#import "ASKAction.h"

@interface ASKLikeupdate : ASKRepresentation


@property (nonatomic, strong) NSNumber * postId;

@property (nonatomic, strong) ASKAction * action;

+ (instancetype)representation;

@end