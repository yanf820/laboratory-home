#import "ASKContent.h"

@implementation ASKContent

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"title: %@\n",self.title];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"title" : _GetNullable(self.title),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKContent *result = [self representation];
    result.title = _Nulled(aDictionary[@"title"]);

    return result;
}

@end
