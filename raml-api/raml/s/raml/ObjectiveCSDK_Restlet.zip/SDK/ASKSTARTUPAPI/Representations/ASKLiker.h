#import "ASKRepresentation.h"


@interface ASKLiker : ASKRepresentation


@property (nonatomic, strong) NSNumber * $id;

@property (nonatomic, copy) NSString * name;

@property (nonatomic, copy) NSString * image;

+ (instancetype)representation;

@end