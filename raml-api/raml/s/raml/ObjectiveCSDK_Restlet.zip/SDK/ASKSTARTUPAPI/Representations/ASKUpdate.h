#import "ASKRepresentation.h"

#import "ASKResult.h"

@interface ASKUpdate : ASKRepresentation


@property (nonatomic, strong) NSNumber * updateObjectId;

@property (nonatomic, strong) ASKResult * result;

@property (nonatomic, copy) NSString * updateTime;

+ (instancetype)representation;

@end