#import "ASKRepresentation.h"


@interface ASKAction : ASKRepresentation


+ (instancetype)representation;

@end