#import "ASKRepresentation.h"


@interface ASKFollow : ASKRepresentation


@property (nonatomic, strong) NSNumber * topicId;

+ (instancetype)representation;

@end