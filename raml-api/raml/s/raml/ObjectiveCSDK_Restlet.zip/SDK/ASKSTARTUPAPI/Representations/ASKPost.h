#import "ASKRepresentation.h"


@interface ASKPost : ASKRepresentation

/** 
 ID
 */
@property (nonatomic, copy) NSString * $id;
/** 
 创建时间
 */
@property (nonatomic, copy) NSString * createTime;
/** 
 当前状态
 */
@property (nonatomic, copy) NSString * status;

+ (instancetype)representation;

@end