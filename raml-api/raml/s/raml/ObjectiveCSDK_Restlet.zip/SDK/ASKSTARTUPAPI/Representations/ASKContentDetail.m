#import "ASKContentDetail.h"

@implementation ASKContentDetail

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"contentText: %@\n",self.contentText];
    [result appendFormat:@"contentImage: %@\n",self.contentImage];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"contentText" : _GetNullable(self.contentText),
                @"contentImage" : _GetNullable(self.contentImage),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKContentDetail *result = [self representation];
    result.contentText = _Nulled(aDictionary[@"contentText"]);
    result.contentImage = _Nulled(aDictionary[@"contentImage"]);

    return result;
}

@end
