#import "ASKRepresentation.h"


@interface ASKPublisher : ASKRepresentation


@property (nonatomic, strong) NSNumber * $id;

@property (nonatomic, copy) NSString * name;

+ (instancetype)representation;

@end