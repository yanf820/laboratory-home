#import "ASKRepresentation.h"

/** 
 主题集合
 */
@interface ASKTopics : ASKRepresentation


+ (instancetype)representation;

@end