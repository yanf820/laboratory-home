#import "ASKLikeupdate.h"

@implementation ASKLikeupdate

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"postId: %@\n",self.postId];
    [result appendFormat:@"action: %@\n",self.action];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"postId" : _GetNullable(self.postId),
                @"action" : _GetNullable([self.action toDictionary]),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKLikeupdate *result = [self representation];
    result.postId = _Nulled(aDictionary[@"postId"]);
    result.action = [ASKAction fromDictionary:_Nulled(aDictionary[@"action"])];

    return result;
}

@end
