#import "ASKFollow.h"

@implementation ASKFollow

+ (instancetype)representation {
    return [[self alloc] init];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];

    [result appendFormat:@"topicId: %@\n",self.topicId];

    return result;
}

#pragma mark - Dictionary Representation

- (NSDictionary *)toDictionary {
    return @{
                @"topicId" : _GetNullable(self.topicId),
            };
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    if (aDictionary == nil) {
        return nil;
    }

    ASKFollow *result = [self representation];
    result.topicId = _Nulled(aDictionary[@"topicId"]);

    return result;
}

@end
