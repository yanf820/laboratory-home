#import "ASKRepresentation.h"


@interface ASKContentDetail : ASKRepresentation


@property (nonatomic, copy) NSString * contentText;

@property (nonatomic, copy) NSString * contentImage;

+ (instancetype)representation;

@end