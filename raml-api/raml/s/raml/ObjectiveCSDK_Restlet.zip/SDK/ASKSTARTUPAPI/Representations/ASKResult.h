#import "ASKRepresentation.h"


@interface ASKResult : ASKRepresentation


@property (nonatomic, strong) NSNumber * updateResultEnum;

+ (instancetype)representation;

@end