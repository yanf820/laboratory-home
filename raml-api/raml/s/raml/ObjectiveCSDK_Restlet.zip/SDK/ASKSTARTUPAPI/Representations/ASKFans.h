#import "ASKRepresentation.h"


@interface ASKFans : ASKRepresentation


@property (nonatomic, strong) NSNumber * $id;

@property (nonatomic, copy) NSString * name;

@property (nonatomic, copy) NSString * image;

+ (instancetype)representation;

@end