#import "ASKRepresentation.h"

/** 
 错误，请求错误时返回
 */
@interface ASKErrorschema : ASKRepresentation

/** 
 错误码
 */
@property (nonatomic, strong) NSNumber * errorCode;
/** 
 错误信息
 */
@property (nonatomic, copy) NSString * message;
/** 
 请求ID
 */
@property (nonatomic, copy) NSString * requestId;
/** 
 状态码
 */
@property (nonatomic, strong) NSNumber * status;
/** 
 时间戳
 */
@property (nonatomic, strong) NSNumber * timestamp;

+ (instancetype)representation;

@end