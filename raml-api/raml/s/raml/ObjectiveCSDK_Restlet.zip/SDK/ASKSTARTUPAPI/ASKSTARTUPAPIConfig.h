#import <Foundation/Foundation.h>
#import "ASKCore.h"
#import "ASKCommon.h"


@interface ASKSTARTUPAPIConfig : ASKGlobalConfig

+ (instancetype)configuration;

@end
