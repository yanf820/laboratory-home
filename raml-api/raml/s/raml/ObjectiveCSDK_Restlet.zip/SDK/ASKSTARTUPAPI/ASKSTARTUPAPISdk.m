#import "ASKSTARTUPAPISdk.h"

@implementation ASKSTARTUPAPISdk

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
    }
    
    return self;
}

+ (instancetype)sdkWithConfig:(ASKSTARTUPAPIConfig *)aConfig {
    return [[self alloc] initWithConfig:aConfig];
}

+ (instancetype)sdk {
    return [self sdkWithConfig:[ASKSTARTUPAPIConfig configuration]];
}


- (ASKResourceTopicsField_selectors *)resourceTopicsField_selectorsWithField_selectors:(NSString *)aField_selectors {
	return [ASKResourceTopicsField_selectors resourceWithConfig:self.configuration andField_selectors:aField_selectors];
} 

- (ASKResourceTopicsTopic_idPostsfield_selectors *)resourceTopicsTopic_idPostsfield_selectorsWithField_selectors:(NSString *)aField_selectors andTopic_id:(NSString *)aTopic_id {
	return [ASKResourceTopicsTopic_idPostsfield_selectors resourceWithConfig:self.configuration andField_selectors:aField_selectors andTopic_id:aTopic_id];
} 

- (ASKResourceTopicsTopic_idFollow *)resourceTopicsTopic_idFollowWithTopic_id:(NSString *)aTopic_id {
	return [ASKResourceTopicsTopic_idFollow resourceWithConfig:self.configuration andTopic_id:aTopic_id];
} 

- (ASKResourceTopicsTopic_id *)resourceTopicsTopic_idWithTopic_id:(NSString *)aTopic_id {
	return [ASKResourceTopicsTopic_id resourceWithConfig:self.configuration andTopic_id:aTopic_id];
} 

- (ASKResourceTopicsTopic_id_1 *)resourceTopicsTopic_id_1WithTopic_id:(NSString *)aTopic_id {
	return [ASKResourceTopicsTopic_id_1 resourceWithConfig:self.configuration andTopic_id:aTopic_id];
} 

- (ASKResourceTopics *)resourceTopics {
	return [ASKResourceTopics resourceWithConfig:self.configuration];
} 

- (ASKResourcePostsField_selectors *)resourcePostsField_selectorsWithField_selectors:(NSString *)aField_selectors {
	return [ASKResourcePostsField_selectors resourceWithConfig:self.configuration andField_selectors:aField_selectors];
} 

- (ASKResourcePostsPostIdLike *)resourcePostsPostIdLikeWithPostId:(NSString *)aPostId {
	return [ASKResourcePostsPostIdLike resourceWithConfig:self.configuration andPostId:aPostId];
} 

- (ASKResourcePostsPostIdReview *)resourcePostsPostIdReviewWithPostId:(NSString *)aPostId {
	return [ASKResourcePostsPostIdReview resourceWithConfig:self.configuration andPostId:aPostId];
} 

- (ASKResourcePostsPostId *)resourcePostsPostIdWithPostId:(NSString *)aPostId {
	return [ASKResourcePostsPostId resourceWithConfig:self.configuration andPostId:aPostId];
} 

- (ASKResourcePostsPostId_1 *)resourcePostsPostId_1WithPostId:(NSString *)aPostId {
	return [ASKResourcePostsPostId_1 resourceWithConfig:self.configuration andPostId:aPostId];
} 

- (ASKResourcePosts *)resourcePosts {
	return [ASKResourcePosts resourceWithConfig:self.configuration];
} 



@end