#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"



@interface ASKResourcePostsPostId : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * postId;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andPostId:(NSString *)aPostId;


@end