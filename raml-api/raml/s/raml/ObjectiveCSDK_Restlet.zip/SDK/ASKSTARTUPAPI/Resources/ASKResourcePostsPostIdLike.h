#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"

#import "ASKUpdate.h"
#import "ASKError-schema.h"
#import "ASKLike-update.h"


@interface ASKResourcePostsPostIdLike : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * postId;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andPostId:(NSString *)aPostId;


/**
 postPostsPostIdLike
 */
- (void)create:(ASKLike-update *)aRepresentation
       andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 postPostsPostIdLike
 */
- (void)createWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKLike-update *)aRepresentation
                 andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



@end