#import "ASKResourcePostsPostIdReview.h"

#import "ASKCore.h"
#import "ASKCommon.h"

#import "ASKError-schema.h"
#import "ASKContent.h"

static NSString *resourcePath = @"/posts/{postId}/~/review";

@implementation ASKResourcePostsPostIdReview

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andPostId:(NSString *)aPostId {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.postId = aPostId;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andPostId:(NSString *)aPostId {
    return [[self alloc] initWithConfig:aConfig andPostId:aPostId];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{postId}" withString:self.postId];
    return result;
}

#pragma mark - operations on the resource


- (void)create:(ASKContent *)aRepresentation
       andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    [self createWithConfig:nil andRepresentation:aRepresentation andBlock:aBlock];
}

- (void)createWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKContent *)aRepresentation
                 andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {

    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self createWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }
        
    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];        
        
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];

    [manager POST:[self formattedURLString]
       parameters:[aRepresentation toDictionary]
          success:^void(AFHTTPRequestOperation *operation, id responseObject) {
              if (aBlock) {
             	 aBlock(responseObject, nil, operation);
             	 
              }
          }
          failure:^void(AFHTTPRequestOperation *operation, NSError *error) {
              
              [ASKResourceHelper handleError:error
                          forSecurityConfig:securityConfig
                               andOperation:operation
                            andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                                
                                if (aBlock) {
                                    aBlock(nil, error, theOperation);
                                }
                                
                            }
                             andRepeatBlock:^{
                                 [self createWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                             }];              
          }];
    
}



@end