#import "ASKResourceTopics.h"

#import "ASKCore.h"
#import "ASKCommon.h"


static NSString *resourcePath = @"/topics";

@implementation ASKResourceTopics

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig {
    return [[self alloc] initWithConfig:aConfig];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
    return result;
}

#pragma mark - operations on the resource


@end