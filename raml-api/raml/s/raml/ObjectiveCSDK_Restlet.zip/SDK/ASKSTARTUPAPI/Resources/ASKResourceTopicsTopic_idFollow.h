#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"

#import "ASKUpdate.h"
#import "ASKError-schema.h"
#import "ASKFollow.h"


@interface ASKResourceTopicsTopic_idFollow : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * topic_id;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andTopic_id:(NSString *)aTopic_id;


/**
 postTopicsTopic_idFollow
 */
- (void)create:(ASKFollow *)aRepresentation
       andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 postTopicsTopic_idFollow
 */
- (void)createWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKFollow *)aRepresentation
                 andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



@end