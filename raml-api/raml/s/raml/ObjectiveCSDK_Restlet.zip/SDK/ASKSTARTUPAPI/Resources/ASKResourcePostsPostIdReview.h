#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"

#import "ASKError-schema.h"
#import "ASKContent.h"


@interface ASKResourcePostsPostIdReview : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * postId;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andPostId:(NSString *)aPostId;


/**
 postPostsPostIdReview
 */
- (void)create:(ASKContent *)aRepresentation
       andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 postPostsPostIdReview
 */
- (void)createWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKContent *)aRepresentation
                 andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



@end