#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"



@interface ASKResourceTopicsTopic_id : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * topic_id;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andTopic_id:(NSString *)aTopic_id;


@end