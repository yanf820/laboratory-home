#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"



@interface ASKResourceTopics : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration;


@end