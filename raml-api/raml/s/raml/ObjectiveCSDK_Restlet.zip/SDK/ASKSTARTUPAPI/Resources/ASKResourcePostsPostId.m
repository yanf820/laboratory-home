#import "ASKResourcePostsPostId.h"

#import "ASKCore.h"
#import "ASKCommon.h"


static NSString *resourcePath = @"/posts/{postId}/~";

@implementation ASKResourcePostsPostId

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andPostId:(NSString *)aPostId {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.postId = aPostId;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andPostId:(NSString *)aPostId {
    return [[self alloc] initWithConfig:aConfig andPostId:aPostId];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{postId}" withString:self.postId];
    return result;
}

#pragma mark - operations on the resource


@end