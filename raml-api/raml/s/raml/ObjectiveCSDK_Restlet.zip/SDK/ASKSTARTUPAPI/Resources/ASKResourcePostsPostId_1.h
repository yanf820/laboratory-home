#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"

#import "ASKPost.h"
#import "ASKError-schema.h"


@interface ASKResourcePostsPostId_1 : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * postId;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andPostId:(NSString *)aPostId;


/**
 getPostsPostId
 */
- (void)getUsingBlock:(void (^)(ASKPost *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 getPostsPostId

 @param requestConfig It allows you to specify the following query parameter(s):
 - sign string 经过校验后生成值

 */
- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKPost *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



/**
 putPostsPostId
 */
- (void)update:(ASKPost *)aRepresentation
       andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 putPostsPostId
 */
- (void)updateWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKPost *)aRepresentation
                 andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



@end