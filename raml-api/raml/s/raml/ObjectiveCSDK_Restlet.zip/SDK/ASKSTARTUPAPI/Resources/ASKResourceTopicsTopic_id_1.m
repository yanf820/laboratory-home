#import "ASKResourceTopicsTopic_id_1.h"

#import "ASKCore.h"
#import "ASKCommon.h"

#import "ASKTopic.h"
#import "ASKError-schema.h"

static NSString *resourcePath = @"/topics/{topic_id}";

@implementation ASKResourceTopicsTopic_id_1

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andTopic_id:(NSString *)aTopic_id {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.topic_id = aTopic_id;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andTopic_id:(NSString *)aTopic_id {
    return [[self alloc] initWithConfig:aConfig andTopic_id:aTopic_id];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{topic_id}" withString:self.topic_id];
    return result;
}

#pragma mark - operations on the resource


- (void)getUsingBlock:(void (^)(ASKTopic *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    [self getWithConfig:nil andBlock:aBlock];
}

- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKTopic *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self getWithConfig:requestConfig andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }
     
        
    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];
            
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];
                                      
    NSMutableDictionary *parameters = [ASKResourceHelper mergeQueryParametersWithRequestConfig:requestConfig
                                                                              andSecurityConfig:securityConfigForRequest];
    
    [manager GET:[self formattedURLString]
      parameters:parameters
         success:^(AFHTTPRequestOperation *operation, id responseObject) {
             if (aBlock) {
                 ASKTopic *payload = [ASKTopic fromDictionary:responseObject];
                 aBlock(payload, nil, operation);
             }
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error) {

             [ASKResourceHelper handleError:error
                         forSecurityConfig:securityConfig
                              andOperation:operation
                           andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                               
                               if (aBlock) {
                                   aBlock(nil, error, theOperation);
                               }
                               
                           }
                            andRepeatBlock:^{
                                [self getWithConfig:requestConfig andBlock:aBlock];
                            }];
         }];
    
}



- (void)update:(ASKTopic *)aRepresentation
       andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    [self updateWithConfig:nil andRepresentation:aRepresentation andBlock:aBlock];
}

- (void)updateWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKTopic *)aRepresentation
                 andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {

    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self updateWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }


    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];
        
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];
                                      
    [manager PUT:[self formattedURLString]
      parameters:[aRepresentation toDictionary]
         success:^void(AFHTTPRequestOperation *operation, id responseObject) {
             if (aBlock) {
             	 aBlock(responseObject, nil, operation);
             	 
             }
         }
         failure:^void(AFHTTPRequestOperation *operation, NSError *error) {

             [ASKResourceHelper handleError:error
                         forSecurityConfig:securityConfig
                              andOperation:operation
                           andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                               
                               if (aBlock) {
                                   aBlock(nil, error, theOperation);
                               }
                               
                           }
                            andRepeatBlock:^{
                                [self updateWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                            }];
         }];
    
}


@end