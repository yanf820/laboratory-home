#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"



@interface ASKResourcePosts : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration;


@end