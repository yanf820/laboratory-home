#import "ASKResourcePostsPostId_1.h"

#import "ASKCore.h"
#import "ASKCommon.h"

#import "ASKPost.h"
#import "ASKError-schema.h"

static NSString *resourcePath = @"/posts/{postId}";

@implementation ASKResourcePostsPostId_1

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andPostId:(NSString *)aPostId {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.postId = aPostId;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andPostId:(NSString *)aPostId {
    return [[self alloc] initWithConfig:aConfig andPostId:aPostId];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{postId}" withString:self.postId];
    return result;
}

#pragma mark - operations on the resource


- (void)getUsingBlock:(void (^)(ASKPost *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    [self getWithConfig:nil andBlock:aBlock];
}

- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKPost *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self getWithConfig:requestConfig andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }
     
        
    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];
            
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];
                                      
    NSMutableDictionary *parameters = [ASKResourceHelper mergeQueryParametersWithRequestConfig:requestConfig
                                                                              andSecurityConfig:securityConfigForRequest];
    
    [manager GET:[self formattedURLString]
      parameters:parameters
         success:^(AFHTTPRequestOperation *operation, id responseObject) {
             if (aBlock) {
                 ASKPost *payload = [ASKPost fromDictionary:responseObject];
                 aBlock(payload, nil, operation);
             }
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error) {

             [ASKResourceHelper handleError:error
                         forSecurityConfig:securityConfig
                              andOperation:operation
                           andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                               
                               if (aBlock) {
                                   aBlock(nil, error, theOperation);
                               }
                               
                           }
                            andRepeatBlock:^{
                                [self getWithConfig:requestConfig andBlock:aBlock];
                            }];
         }];
    
}



- (void)update:(ASKPost *)aRepresentation
       andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    [self updateWithConfig:nil andRepresentation:aRepresentation andBlock:aBlock];
}

- (void)updateWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKPost *)aRepresentation
                 andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {

    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self updateWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }


    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];
        
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];
                                      
    [manager PUT:[self formattedURLString]
      parameters:[aRepresentation toDictionary]
         success:^void(AFHTTPRequestOperation *operation, id responseObject) {
             if (aBlock) {
             	 aBlock(responseObject, nil, operation);
             	 
             }
         }
         failure:^void(AFHTTPRequestOperation *operation, NSError *error) {

             [ASKResourceHelper handleError:error
                         forSecurityConfig:securityConfig
                              andOperation:operation
                           andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                               
                               if (aBlock) {
                                   aBlock(nil, error, theOperation);
                               }
                               
                           }
                            andRepeatBlock:^{
                                [self updateWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                            }];
         }];
    
}


@end