#import "ASKResourceTopicsTopic_id.h"

#import "ASKCore.h"
#import "ASKCommon.h"


static NSString *resourcePath = @"/topics/{topic_id}/~";

@implementation ASKResourceTopicsTopic_id

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andTopic_id:(NSString *)aTopic_id {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.topic_id = aTopic_id;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andTopic_id:(NSString *)aTopic_id {
    return [[self alloc] initWithConfig:aConfig andTopic_id:aTopic_id];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{topic_id}" withString:self.topic_id];
    return result;
}

#pragma mark - operations on the resource


@end