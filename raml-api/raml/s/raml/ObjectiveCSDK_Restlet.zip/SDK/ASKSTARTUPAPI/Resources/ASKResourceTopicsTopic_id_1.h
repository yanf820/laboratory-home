#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"

#import "ASKTopic.h"
#import "ASKError-schema.h"


@interface ASKResourceTopicsTopic_id_1 : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;


@property (nonatomic, copy) NSString * topic_id;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andTopic_id:(NSString *)aTopic_id;


/**
 getTopicsTopic_id
 */
- (void)getUsingBlock:(void (^)(ASKTopic *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 getTopicsTopic_id

 @param requestConfig It allows you to specify the following query parameter(s):
 - sign string 经过校验后生成值

 */
- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKTopic *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



/**
 putTopicsTopic_id
 */
- (void)update:(ASKTopic *)aRepresentation
       andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 putTopicsTopic_id
 */
- (void)updateWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKTopic *)aRepresentation
                 andBlock:(void (^)(id payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



@end