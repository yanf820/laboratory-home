#import "ASKResourcePostsField_selectors.h"

#import "ASKCore.h"
#import "ASKCommon.h"

#import "ASKPosts.h"
#import "ASKError-schema.h"
#import "ASKUpdate.h"
#import "ASKPost.h"

static NSString *resourcePath = @"/posts/~{field_selectors}";

@implementation ASKResourcePostsField_selectors

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andField_selectors:(NSString *)aField_selectors {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.field_selectors = aField_selectors;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andField_selectors:(NSString *)aField_selectors {
    return [[self alloc] initWithConfig:aConfig andField_selectors:aField_selectors];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{field_selectors}" withString:self.field_selectors];
    return result;
}

#pragma mark - operations on the resource


- (void)getUsingBlock:(void (^)(ASKPosts *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    [self getWithConfig:nil andBlock:aBlock];
}

- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKPosts *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self getWithConfig:requestConfig andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }
     
        
    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];
            
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];
                                      
    NSMutableDictionary *parameters = [ASKResourceHelper mergeQueryParametersWithRequestConfig:requestConfig
                                                                              andSecurityConfig:securityConfigForRequest];
    
    [manager GET:[self formattedURLString]
      parameters:parameters
         success:^(AFHTTPRequestOperation *operation, id responseObject) {
             if (aBlock) {
                 ASKPosts *payload = [ASKPosts fromDictionary:responseObject];
                 aBlock(payload, nil, operation);
             }
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error) {

             [ASKResourceHelper handleError:error
                         forSecurityConfig:securityConfig
                              andOperation:operation
                           andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                               
                               if (aBlock) {
                                   aBlock(nil, error, theOperation);
                               }
                               
                           }
                            andRepeatBlock:^{
                                [self getWithConfig:requestConfig andBlock:aBlock];
                            }];
         }];
    
}



- (void)create:(ASKPost *)aRepresentation
       andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    [self createWithConfig:nil andRepresentation:aRepresentation andBlock:aBlock];
}

- (void)createWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKPost *)aRepresentation
                 andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {

    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self createWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }
        
    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];        
        
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];

    [manager POST:[self formattedURLString]
       parameters:[aRepresentation toDictionary]
          success:^void(AFHTTPRequestOperation *operation, id responseObject) {
              if (aBlock) {
                 ASKUpdate *payload = [ASKUpdate fromDictionary:responseObject];
                 aBlock(payload, nil, operation);
              }
          }
          failure:^void(AFHTTPRequestOperation *operation, NSError *error) {
              
              [ASKResourceHelper handleError:error
                          forSecurityConfig:securityConfig
                               andOperation:operation
                            andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                                
                                if (aBlock) {
                                    aBlock(nil, error, theOperation);
                                }
                                
                            }
                             andRepeatBlock:^{
                                 [self createWithConfig:requestConfig andRepresentation:aRepresentation andBlock:aBlock];
                             }];              
          }];
    
}



@end