#import "ASKResourceTopicsTopic_idPostsfield_selectors.h"

#import "ASKCore.h"
#import "ASKCommon.h"

#import "ASKPosts.h"
#import "ASKError-schema.h"

static NSString *resourcePath = @"/topics/{topic_id}/~/posts{field_selectors}";

@implementation ASKResourceTopicsTopic_idPostsfield_selectors

- (instancetype)initWithConfig:(ASKSTARTUPAPIConfig *)aConfig andField_selectors:(NSString *)aField_selectors andTopic_id:(NSString *)aTopic_id {
    self = [super init];
    
    if (self) {
        self.configuration = aConfig;
        self.field_selectors = aField_selectors;
        self.topic_id = aTopic_id;
    }
    
    return self;
}

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)aConfig andField_selectors:(NSString *)aField_selectors andTopic_id:(NSString *)aTopic_id {
    return [[self alloc] initWithConfig:aConfig andField_selectors:aField_selectors andTopic_id:aTopic_id];
}

#pragma mark - utils

- (NSString *)formattedURLString {

    NSString *result = [self.configuration.endPoint stringByAppendingString:resourcePath];
	result = [result stringByReplacingOccurrencesOfString:@"{field_selectors}" withString:self.field_selectors];
	result = [result stringByReplacingOccurrencesOfString:@"{topic_id}" withString:self.topic_id];
    return result;
}

#pragma mark - operations on the resource


- (void)getUsingBlock:(void (^)(ASKPosts *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    [self getWithConfig:nil andBlock:aBlock];
}

- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKPosts *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock {
    
    ASKSecurityConfig *securityConfig = [ASKResourceHelper getSecurityConfigFromSchemes:@[  ]
                                                                      andConfiguration:self.configuration];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [ASKManagerHelper updateManager:manager withSecurityConfig:securityConfig];

    if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
        [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                         success:^{
                                                             [self getWithConfig:requestConfig andBlock:aBlock];
                                                         }
                                                         failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                             if (aBlock) {
                                                                 aBlock(nil, error, operation);
                                                             }
                                                         }];    
        return;
    }
     
        
    ASKRequestConfig *securityConfigForRequest = [ASKResourceHelper getSecurityFromConfig:securityConfig];
            
	[ASKResourceHelper addHeadersWithRequestConfig:requestConfig
                                 andSecurityConfig:securityConfigForRequest
                               toRequestSerializer:manager.requestSerializer];
                                      
    NSMutableDictionary *parameters = [ASKResourceHelper mergeQueryParametersWithRequestConfig:requestConfig
                                                                              andSecurityConfig:securityConfigForRequest];
    
    [manager GET:[self formattedURLString]
      parameters:parameters
         success:^(AFHTTPRequestOperation *operation, id responseObject) {
             if (aBlock) {
                 ASKPosts *payload = [ASKPosts fromDictionary:responseObject];
                 aBlock(payload, nil, operation);
             }
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error) {

             [ASKResourceHelper handleError:error
                         forSecurityConfig:securityConfig
                              andOperation:operation
                           andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                               
                               if (aBlock) {
                                   aBlock(nil, error, theOperation);
                               }
                               
                           }
                            andRepeatBlock:^{
                                [self getWithConfig:requestConfig andBlock:aBlock];
                            }];
         }];
    
}



@end