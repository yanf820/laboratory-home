#import <Foundation/Foundation.h>
#import "AFNetworking.h"

#import "ASKSTARTUPAPIConfig.h"

#import "ASKTopics.h"
#import "ASKError-schema.h"
#import "ASKUpdate.h"
#import "ASKTopic.h"


@interface ASKResourceTopicsField_selectors : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;

/** 
 很多资源允许你指定想要返回的字段。我们称这种语法结构为字段选择器。通过准确的指出你需要的信息，我们可以优化返回结果花费的时间。
这样也能减少传输的数据。这两点让我们的APIs快速且高效，这是任何一个web应用程序的关键点，对于其他任何依赖外部API的人来说更是如此。

Example
--------
如果想要获得people先关的id,first-name,last-name,industry可以这样使用:
  `http://api.startupsass.com/v1/people/~:(id,first-name,last-name,industry)`

或者:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,industry)`

字段选择器可以选择成员对象中的字段:
  `http://api.startupsass.com/v1/people/~/connections:(id,first-name,last-name,positions:(title))`

 */
@property (nonatomic, copy) NSString * field_selectors;

+ (instancetype)resourceWithConfig:(ASKSTARTUPAPIConfig *)configuration andField_selectors:(NSString *)aField_selectors;


/**
 getTopicsField_selectors
 */
- (void)getUsingBlock:(void (^)(ASKTopics *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 getTopicsField_selectors

 @param requestConfig It allows you to specify the following query parameter(s):
 - keywords string null
 - count long Maximum
 - start long The offset by which to start Network Update pagination
 - sign string 经过校验后生成值

 */
- (void)getWithConfig:(ASKRequestConfig *)requestConfig
              andBlock:(void (^)(ASKTopics *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



/**
 postTopicsField_selectors
 */
- (void)create:(ASKTopic *)aRepresentation
       andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;

/**
 postTopicsField_selectors
 */
- (void)createWithConfig:(ASKRequestConfig *)requestConfig
        andRepresentation:(ASKTopic *)aRepresentation
                 andBlock:(void (^)(ASKUpdate *payload, NSError *error, AFHTTPRequestOperation *operation))aBlock;



@end