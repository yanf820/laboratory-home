#import <Foundation/Foundation.h>
#import "ASKCommon.h"
#import "ASKResourceTopicsField_selectors.h"
#import "ASKResourceTopicsTopic_idPostsfield_selectors.h"
#import "ASKResourceTopicsTopic_idFollow.h"
#import "ASKResourceTopicsTopic_id.h"
#import "ASKResourceTopicsTopic_id_1.h"
#import "ASKResourceTopics.h"
#import "ASKResourcePostsField_selectors.h"
#import "ASKResourcePostsPostIdLike.h"
#import "ASKResourcePostsPostIdReview.h"
#import "ASKResourcePostsPostId.h"
#import "ASKResourcePostsPostId_1.h"
#import "ASKResourcePosts.h"


@interface ASKSTARTUPAPISdk : NSObject

@property (nonatomic, strong) ASKSTARTUPAPIConfig *configuration;

+ (instancetype)sdkWithConfig:(ASKSTARTUPAPIConfig *)aConfig;
+ (instancetype)sdk;

- (ASKResourceTopicsField_selectors *)resourceTopicsField_selectorsWithField_selectors:(NSString *)aField_selectors;
 
- (ASKResourceTopicsTopic_idPostsfield_selectors *)resourceTopicsTopic_idPostsfield_selectorsWithField_selectors:(NSString *)aField_selectors andTopic_id:(NSString *)aTopic_id;
 
- (ASKResourceTopicsTopic_idFollow *)resourceTopicsTopic_idFollowWithTopic_id:(NSString *)aTopic_id;
 
- (ASKResourceTopicsTopic_id *)resourceTopicsTopic_idWithTopic_id:(NSString *)aTopic_id;
 
- (ASKResourceTopicsTopic_id_1 *)resourceTopicsTopic_id_1WithTopic_id:(NSString *)aTopic_id;
 
- (ASKResourceTopics *)resourceTopics;
 
- (ASKResourcePostsField_selectors *)resourcePostsField_selectorsWithField_selectors:(NSString *)aField_selectors;
 
- (ASKResourcePostsPostIdLike *)resourcePostsPostIdLikeWithPostId:(NSString *)aPostId;
 
- (ASKResourcePostsPostIdReview *)resourcePostsPostIdReviewWithPostId:(NSString *)aPostId;
 
- (ASKResourcePostsPostId *)resourcePostsPostIdWithPostId:(NSString *)aPostId;
 
- (ASKResourcePostsPostId_1 *)resourcePostsPostId_1WithPostId:(NSString *)aPostId;
 
- (ASKResourcePosts *)resourcePosts;
 

@end