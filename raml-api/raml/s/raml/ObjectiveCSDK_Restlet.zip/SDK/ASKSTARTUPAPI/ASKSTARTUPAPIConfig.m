#import "ASKSTARTUPAPIConfig.h"
#import "ASKSecurityHelper.h"

@implementation ASKSTARTUPAPIConfig

+ (instancetype)configuration {

    ASKSTARTUPAPIConfig * config = [[super alloc] initWithEndPoint:@"http://api.startupsass.com"];


    return config;
}


@end
