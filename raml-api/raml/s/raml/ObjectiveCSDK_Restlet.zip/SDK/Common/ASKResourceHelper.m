#import "ASKResourceHelper.h"

@implementation ASKResourceHelper

#pragma mark - headers utils

+ (void)addHeadersWithRequestConfig:(ASKRequestConfig *)requestConfig
                  andSecurityConfig:(ASKRequestConfig *)securityConfig
                toRequestSerializer:(AFHTTPRequestSerializer *)requestSerializer {
    
    NSMutableDictionary *allHeaders = [NSMutableDictionary dictionary];
    
    [allHeaders addEntriesFromDictionary:securityConfig.headers];
    
    [allHeaders addEntriesFromDictionary:requestConfig.headers];
    
    [allHeaders enumerateKeysAndObjectsUsingBlock:^(id header, id value, BOOL *stop) {
        [requestSerializer setValue:value forHTTPHeaderField:header];
    }];
    
}

#pragma mark - query parameters utils

+ (NSMutableDictionary *)mergeQueryParametersWithRequestConfig:(ASKRequestConfig *)requestConfig
                                             andSecurityConfig:(ASKRequestConfig *)securityConfig {
    
    NSMutableDictionary *allQueryParameters = [NSMutableDictionary dictionary];
    
    [allQueryParameters addEntriesFromDictionary:securityConfig.queryParameters];
    
    [allQueryParameters addEntriesFromDictionary:requestConfig.queryParameters];
    
    return allQueryParameters;
}

#pragma mark - security utils

+ (ASKSecurityConfig *)getSecurityConfigFromSchemes:(NSArray *)schemeKeys
                                  andConfiguration:(ASKGlobalConfig *)config {
    
    if ([schemeKeys count] == 0) {
        return config.globalSecurity;
    }
    
    for (int i=0; i < [schemeKeys count]; i++) {
        
        NSString *schemeKey = schemeKeys[i];
        
        if (!config.securityConfigs[schemeKey]) {
            continue;
        }
        
        if ([ASKResourceHelper isNotAuthenticated:schemeKey]) {
            return nil;
        } else {
            return config.securityConfigs[schemeKey];
        }
        
    }
    
    NSLog(@"At least one of these security schemes %@ must be setup with [mySDK.config configure...]", schemeKeys);
    
    return nil;
}

+ (ASKRequestConfig *)getSecurityFromConfig:(ASKSecurityConfig *)securityConfig {
    
    if (!securityConfig) {
        return nil;
    }
    
    ASKRequestConfig *requestConfig = [ASKRequestConfig requestConfig];
    
    if ([securityConfig.type isEqualToString:@"BASIC"]) {
        
        requestConfig.headers[@"Authorization"] = securityConfig.value;
        
    } else if ([securityConfig.type isEqualToString:@"API_KEY"]
               && [securityConfig.placement isEqualToString:@"HEADER"]) {
        
        requestConfig.headers[securityConfig.name] = securityConfig.value;
        
    } else if ([securityConfig.type isEqualToString:@"API_KEY"]
               && [securityConfig.placement isEqualToString:@"QUERY"]) {
        
        requestConfig.queryParameters[securityConfig.name] = securityConfig.value;
        
    } else if ([securityConfig.type isEqualToString:@"OAUTH2"]) {
        
        if (securityConfig.oauth2ShouldPassAccessTokenAsQueryParameter) {
            requestConfig.queryParameters[@"access_token"] = securityConfig.oauth2AccessToken;
        } else {
            requestConfig.headers[@"Authorization"] = securityConfig.value;
        }
        
    } else {
        NSLog(@"Unknown scheme: No config will be applied.");
    }
    
    return requestConfig;
}

+ (BOOL)isNotAuthenticated:(NSString *)securityKey {
    return [securityKey isEqualToString:@"_NONE"];
}

#pragma mark - error handlers

+ (void)handleError:(NSError *)error
  forSecurityConfig:(ASKSecurityConfig *)securityConfig
       andOperation:(AFHTTPRequestOperation *)operation
    andFailureBlock:(void (^)(NSError *error, AFHTTPRequestOperation *operation))failureBlock
     andRepeatBlock:(void (^)())repeatBlock
{

    if ([securityConfig.oauth2Grant isEqualToString:@"resourceOwnerPassword"]) {
        
        [ASKOAuth2PasswordFlowHelper handleRequestError:error
                                     forSecurityConfig:securityConfig
                                          andOperation:operation
                                       andFailureBlock:failureBlock
                                        andRepeatBlock:repeatBlock];
    } else {
        failureBlock(error, operation);
    }

}

@end
