#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "ASKCore.h"
#import "ASKRequestConfig.h"
#import "ASKGlobalConfig.h"


@interface ASKResourceHelper : NSObject

+ (void)addHeadersWithRequestConfig:(ASKRequestConfig *)requestConfig
                  andSecurityConfig:(ASKRequestConfig *)securityConfig
                toRequestSerializer:(AFHTTPRequestSerializer *)requestSerializer;

+ (NSMutableDictionary *)mergeQueryParametersWithRequestConfig:(ASKRequestConfig *)requestConfig
                                             andSecurityConfig:(ASKRequestConfig *)securityConfig;

+ (ASKSecurityConfig *)getSecurityConfigFromSchemes:(NSArray *)securityKeys
                                  andConfiguration:(ASKGlobalConfig *)config;

+ (ASKRequestConfig *)getSecurityFromConfig:(ASKSecurityConfig *)securityConfig;

+ (void)handleError:(NSError *)error
  forSecurityConfig:(ASKSecurityConfig *)securityConfig
       andOperation:(AFHTTPRequestOperation *)operation
    andFailureBlock:(void (^)(NSError *error, AFHTTPRequestOperation *operation))failureBlock
     andRepeatBlock:(void (^)())repeatBlock;

@end
