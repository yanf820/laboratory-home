#import "ASKRequestConfig.h"

@implementation ASKRequestConfig

- (instancetype)init {
    self = [super init];
    
    if (self) {
        self.headers = [[NSMutableDictionary alloc] init];
        self.queryParameters = [[NSMutableDictionary alloc] init];
    }
    
    return self;
}

+ (instancetype)requestConfig {
    return [[self alloc] init];
}




@end
