#import <Foundation/Foundation.h>

@interface ASKFile: NSObject

@property (nonatomic, copy) NSData *fileContent;

@property (nonatomic, copy) NSString *fileName;

@property (nonatomic, copy) NSString *mediaType;

+ (instancetype) file;
+ (instancetype) fileWithData:(NSData*)data andFilename:(NSString*)fileName andMediaType:(NSString*)mediaType;

@end