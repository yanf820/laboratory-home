#import <Foundation/Foundation.h>
#import "NSArray+Map.h"

@implementation NSArray (Map)

- (instancetype)mapUsingBlock:(id (^)(id object)) aBlock {
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:[self count]];
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        id result = aBlock(obj);
        [array addObject:result];
    }];
    return array;
}
@end
