#import "NSDate+TimeStampRepresentation.h"

@implementation NSDate (TimeStampRepresentation)

- (NSNumber *)timeStampRepresentation {
    return @((long)floor([self timeIntervalSince1970]*1000));
}

+ (instancetype)dateWithTimeStampRepresentation:(NSNumber *)aTimeStampRepresentation {
    return aTimeStampRepresentation?[self dateWithTimeIntervalSince1970:[aTimeStampRepresentation longValue]*0.001]:nil;
}

@end
