#import <Foundation/Foundation.h>

@interface NSArray (Map)

- (instancetype)mapUsingBlock:(id (^)(id object)) aBlock;

@end
