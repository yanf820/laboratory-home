#import <Foundation/Foundation.h>

@interface NSDate (TimeStampRepresentation)

- (NSNumber *)timeStampRepresentation;

+ (instancetype)dateWithTimeStampRepresentation:(NSNumber *)aTimeStampRepresentation;

@end
