#import <Foundation/Foundation.h>

#define ISO8601_FORMAT_DATETIME @"yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ"
#define ISO8601_FORMAT_DATE @"yyyy-MM-dd"

@interface NSDate (ISO8601)

- (NSString *)iso8601Datetime;
- (NSString *)iso8601Date;

+ (instancetype)dateWithISO8601Datetime:(NSString *)iso8601Format;
+ (instancetype)dateWithISO8601Date:(NSString *)iso8601Format;

@end
