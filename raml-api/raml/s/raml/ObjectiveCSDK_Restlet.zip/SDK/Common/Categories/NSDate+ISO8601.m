#import "NSDate+ISO8601.h"

@implementation NSDate (ISO8601)

- (NSString *)iso8601Datetime {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:ISO8601_FORMAT_DATETIME];
    return [dateFormatter stringFromDate:self];
}

- (NSString *)iso8601Date {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:ISO8601_FORMAT_DATE];
    return [dateFormatter stringFromDate:self];
}

+ (instancetype)dateWithISO8601Datetime:(NSString *)iso8601Format {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:ISO8601_FORMAT_DATETIME];
    return [dateFormatter dateFromString:iso8601Format];
}

+ (instancetype)dateWithISO8601Date:(NSString *)iso8601Format {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:ISO8601_FORMAT_DATE];
    return [dateFormatter dateFromString:iso8601Format];
}

@end
