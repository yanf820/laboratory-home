#import "ASKRepresentation.h"

@implementation ASKRepresentation

- (NSDictionary *)toDictionary {
    return @{};
}

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary {
    return nil;
}

@end
