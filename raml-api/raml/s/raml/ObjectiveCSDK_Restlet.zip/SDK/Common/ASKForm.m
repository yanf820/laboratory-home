#import "ASKForm.h"

@implementation ASKForm

- (instancetype)init {
    self = [super init];
    
    if (self) {
        self.parameters = [NSMutableDictionary<NSString *, id> dictionary];
        self.files = [NSMutableDictionary<NSString *, id> dictionary];
    }
    
    return self;
}

+ (instancetype) form {
    return [[self alloc] init];
}

- (void)serializeFiles:(id<AFMultipartFormData>) formData {
    [self.files enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[NSMutableArray class]]) {
            NSMutableArray<ASKFile *> *array = (NSMutableArray<ASKFile *> *)obj;
            [array enumerateObjectsUsingBlock:^(ASKFile * _Nonnull file, NSUInteger idx, BOOL * _Nonnull stop) {
                [formData appendPartWithFileData:file.fileContent name:key fileName:file.fileName mimeType:file.mediaType];
            }];
        } else {
            ASKFile *file = (ASKFile *) obj;
            [formData appendPartWithFileData:file.fileContent name:key fileName:file.fileName mimeType:file.mediaType];
        }
    }];
}

- (void)checkRequiredFields:(NSArray<NSString*> *)requiredFields andError:(NSError * __autoreleasing *)error {
    NSMutableArray *errors = [NSMutableArray array];
    [requiredFields enumerateObjectsUsingBlock:^(NSString * _Nonnull field, NSUInteger idx, BOOL * _Nonnull stop) {
        if (!self.parameters[field] && !self.files[field]) {
            [errors addObject:field];
        }
    }];
    
    if ([errors count] > 0) {
        NSString *reason = [NSString stringWithFormat:@"Missing keys: %@", [errors componentsJoinedByString:@", "]];
        *error = [NSError errorWithDomain:ASK_ERROR_DOMAIN code:RequiredValidationError userInfo:@{NSLocalizedDescriptionKey: @"Some required fields are missing.",
                                                                                                  NSLocalizedFailureReasonErrorKey: reason }];
    }
}

- (void)addUniqueField:(NSString*)key andValue:(NSString*)value {
    self.parameters[key] = value;
}

- (void)addUniqueField:(NSString*)key andValue:(NSNumber*)value withMinimumValue:(NSNumber *)min andMaximumValue:(NSNumber *)max andError:(NSError * __autoreleasing *)error {
    BOOL isValid = [self checkValidityForField:key andValue:value withMin:min andMax:max andError:error];
    
    if (!isValid) {
        return;
    }
    
    [self addUniqueField:key andValue:[value stringValue]];
}

- (void)addMultipleField:(NSString*)key andValue:(NSString*)value {
    if (!self.parameters[key]) {
        self.parameters[key] = [NSMutableArray arrayWithObject:value];
    } else {
        [self.parameters[key] addObject:value];
    }
}

- (void)addMultipleField:(NSString*)key andValue:(NSNumber*)value withMinimumValue:(NSNumber *)min andMaximumValue:(NSNumber *)max andError:(NSError * __autoreleasing *)error {
    BOOL isValid = [self checkValidityForField:key andValue:value withMin:min andMax:max andError:error];
    
    if (!isValid) {
        return;
    }
    
    [self addMultipleField:key andValue:[value stringValue]];
}

- (void)addUniqueFile:(ASKFile*)file forKey:(NSString*)key {
    self.files[key] = file;
}

- (void)addMultipleFile:(ASKFile*)file forKey:(NSString*)key {
    if (!self.files[key]) {
        self.files[key] = [NSMutableArray arrayWithObject:file];
    } else {
        [self.files[key] addObject:file];
    }
}

- (BOOL)checkValidityForField:(NSString*)key andValue:(NSNumber *)value withMin:(NSNumber *)min andMax:(NSNumber*)max andError:(NSError * __autoreleasing *)error {
    if (min && ([min doubleValue] > [value doubleValue])) {
        NSString* reason = [NSString stringWithFormat:@"For field %@ the value should be over %@ and was %@", key, [min stringValue], [value stringValue]];
        *error = [NSError errorWithDomain:ASK_ERROR_DOMAIN code:MinValidationError userInfo:@{NSLocalizedDescriptionKey: @"Provided value is below minimum",
                                                                                             NSLocalizedFailureReasonErrorKey: reason}];
        return NO;
    }
    if (max && ([max doubleValue] < [value doubleValue])) {
        NSString* reason = [NSString stringWithFormat:@"For field %@ the value should be under %@ and was %@", key, [max stringValue], [value stringValue]];
        *error = [NSError errorWithDomain:ASK_ERROR_DOMAIN code:MaxValidationError userInfo:@{NSLocalizedDescriptionKey: @"Provided value is over maximum",
                                                                                             NSLocalizedFailureReasonErrorKey: reason}];
        return NO;
    }
    return YES;
}

@end