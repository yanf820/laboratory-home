#import <Foundation/Foundation.h>
#import "NSDate+TimeStampRepresentation.h"
#import "NSDate+ISO8601.h"
#import "NSArray+Map.h"

#define _GetNullable(o) (o?o:[NSNull null])
#define _Nulled(o) ([o isEqual:[NSNull null]]?nil:o)

@interface ASKRepresentation : NSObject

- (NSDictionary *)toDictionary;

+ (instancetype)fromDictionary:(NSDictionary *)aDictionary;

@end
