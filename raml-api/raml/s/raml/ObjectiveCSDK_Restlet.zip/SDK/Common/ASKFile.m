#import "ASKFile.h"

@implementation ASKFile

- (instancetype) init {
    return [super init];
}

- (instancetype) initWithData:(NSData*)data andFilename:(NSString*)fileName andMediaType:(NSString*)mediaType {
    self = [self init];
    self.fileContent = data;
    self.fileName = fileName;
    self.mediaType = mediaType;
    return self;
}

+ (instancetype) file {
    return [[self alloc] init];
}

+ (instancetype) fileWithData:(NSData*)data andFilename:(NSString*)fileName andMediaType:(NSString*)mediaType {
    return [[self alloc] initWithData:data andFilename:fileName andMediaType:mediaType];
}

- (NSString *)description {
    NSMutableString *result = [NSMutableString string];
    
    [result appendFormat:@"fileName: %@\n",self.fileName];
    [result appendFormat:@"mediaType: %@\n",self.mediaType];
    
    return result;
}

@end