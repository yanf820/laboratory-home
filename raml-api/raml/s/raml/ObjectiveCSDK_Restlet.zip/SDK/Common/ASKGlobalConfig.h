#import <Foundation/Foundation.h>
#import "ASKCore.h"

@interface ASKGlobalConfig : NSObject

@property (nonatomic, copy) NSString *endPoint;
@property (nonatomic, strong) ASKSecurityConfig *globalSecurity;
@property (nonatomic, strong) NSMutableDictionary *securityConfigs;

- (instancetype)initWithEndPoint:(NSString *)endpoint;

+ (instancetype)configuration;

- (void)setBasicAuthWithUsername:(NSString *)username
                     andPassword:(NSString *)password;

- (void)setApiTokenAsQueryParameterWithName:(NSString *)name
                                   andValue:(NSString *)value;

- (void)setApiTokenAsHeaderWithName:(NSString *)name
                           andValue:(NSString *)value;

- (void)setOAuth2ImplicitFlowWithAccessToken:(NSString *)accessToken;

- (void)setOAuth2PasswordFlowWithAccessToken:(NSString *)accessToken
                             andRefreshToken:(NSString *)refreshToken
                                 andClientId:(NSString *)clientId
                             andClientSecret:(NSString *)clientSecret
                          andRefreshTokenURL:(NSString *)refreshTokenURL;

- (void)allowSelfSignedCertificates;

@end