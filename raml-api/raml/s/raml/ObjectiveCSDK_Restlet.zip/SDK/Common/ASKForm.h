#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "NSDate+TimeStampRepresentation.h"
#import "NSDate+ISO8601.h"
#import "NSArray+Map.h"
#import "ASKErrors.h"
#import "ASKFile.h"

#define _Nullable(o) (o?o:[NSNull null])

@interface ASKForm : NSObject

@property (nonatomic, strong) NSMutableDictionary<NSString*, id> *parameters;
@property (nonatomic, strong) NSMutableDictionary<NSString*, id> *files;

- (instancetype)init;
+ (instancetype)form;

- (void)serializeFiles:(id<AFMultipartFormData>) formData;
- (void)checkRequiredFields:(NSArray<NSString*> *)requiredFields andError:(NSError * __autoreleasing *)error;
- (void)addUniqueField:(NSString*)key andValue:(NSString*)value;
- (void)addUniqueField:(NSString*)key andValue:(NSNumber*)value withMinimumValue:(NSNumber*)min andMaximumValue:(NSNumber*)max andError:(NSError * __autoreleasing *)error;
- (void)addMultipleField:(NSString*)key andValue:(NSString*)value;
- (void)addMultipleField:(NSString*)key andValue:(NSNumber*)value withMinimumValue:(NSNumber*)min andMaximumValue:(NSNumber*)max andError:(NSError * __autoreleasing *)error;
- (void)addUniqueFile:(ASKFile*)file forKey:(NSString*)key;
- (void)addMultipleFile:(ASKFile*)file forKey:(NSString*)key;

@end