#define ASK_ERROR_DOMAIN @"sdk.generated"

typedef NS_ENUM(NSInteger, ASKErrorCode) {
    MinValidationError = 1001,
    MaxValidationError = 1002,
    EnumValidationError = 1003,
    RequiredValidationError = 1004
    
};

