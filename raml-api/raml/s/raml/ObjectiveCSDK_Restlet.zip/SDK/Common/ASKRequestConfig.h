#import <Foundation/Foundation.h>

@interface ASKRequestConfig : NSObject

@property (nonatomic, strong) NSMutableDictionary *headers;
@property (nonatomic, strong) NSMutableDictionary *queryParameters;

+ (instancetype)requestConfig;

@end
