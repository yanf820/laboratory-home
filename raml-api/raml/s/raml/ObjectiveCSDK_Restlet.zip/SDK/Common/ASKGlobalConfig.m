#import "ASKGlobalConfig.h"

static NSString * const keyGlobal = @"kGlobal";

@implementation ASKGlobalConfig

- (instancetype)init {
    self = [super init];
    
    if (self) {
        self.globalSecurity = [ASKSecurityConfig securityConfig];
        self.securityConfigs = [NSMutableDictionary dictionary];
    }
    
    return self;
}

- (instancetype)initWithEndPoint:(NSString *)endpoint {
    self = [self init];
    self.endPoint = endpoint;
    
    return self;
}

+ (instancetype)configuration {
    return [[self alloc] init];
}

- (void)setBasicAuthWithUsername:(NSString *)username
                     andPassword:(NSString *)password {
    
    self.globalSecurity = [ASKSecurityHelper getConfigBasicWithUsername:username andPassword:password andSchemeKey:keyGlobal];
}

- (void)setApiTokenAsHeaderWithName:(NSString *)name
                           andValue:(NSString *)value {
    
    self.globalSecurity = [ASKSecurityHelper getConfigApiTokenAsHeaderWithName:name andValue:value andSchemeKey:keyGlobal];
}

- (void)setApiTokenAsQueryParameterWithName:(NSString *)name
                                   andValue:(NSString *)value {
    
    self.globalSecurity = [ASKSecurityHelper getConfigApiTokenAsQueryParameterWithName:name andValue:value andSchemeKey:keyGlobal];
}

- (void)setOAuth2ImplicitFlowWithAccessToken:(NSString *)accessToken {
    
    self.globalSecurity = [ASKSecurityHelper getConfigOAuth2ForImplicitWithAccessToken:accessToken andSchemeKey:keyGlobal];
}

- (void)setOAuth2PasswordFlowWithAccessToken:(NSString *)accessToken
                             andRefreshToken:(NSString *)refreshToken
                                 andClientId:(NSString *)clientId
                             andClientSecret:(NSString *)clientSecret
                          andRefreshTokenURL:(NSString *)refreshTokenURL {
    
    self.globalSecurity = [ASKSecurityHelper getConfigOAuth2ForPasswordWithAccessToken:accessToken
                                                                      andRefreshToken:refreshToken
                                                                          andClientId:clientId
                                                                      andClientSecret:clientSecret
                                                                   andRefreshTokenURL:refreshTokenURL
                                                                         andSchemeKey:keyGlobal];
}

- (void)allowSelfSignedCertificates {

    [self.securityConfigs enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {

        ASKSecurityConfig* securityConfig = (ASKSecurityConfig*)obj;
        securityConfig.allowSelfSignedCertificates = YES;

    }];

    self.globalSecurity.allowSelfSignedCertificates = YES;
}

@end
