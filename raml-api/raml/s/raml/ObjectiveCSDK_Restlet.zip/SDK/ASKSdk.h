#import "ASKGlobalConfig.h"
#import "ASKRequestConfig.h"
#import "ASKRepresentation.h"

#import "ASKSTARTUPAPISdk.h"

@interface ASKSdk : NSObject

+ (ASKSTARTUPAPISdk *)sTARTUPAPISdk;
+ (ASKSTARTUPAPISdk *)sTARTUPAPISdkWithConfig:(ASKSTARTUPAPIConfig *)aConfig;

@end
