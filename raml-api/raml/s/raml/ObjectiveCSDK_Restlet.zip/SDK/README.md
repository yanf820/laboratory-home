# How to get started

Open Xcode. Drag and drop the SDK folder in your project. When the `Choose options for adding these files` modal opens, select the following options:
- Destination: (checked) Copy items if needed
- Added folders: (checked) Create groups
- Add to targets: (checked) your application

Build and run your application.

# Usage principles

As a first step, you need to instantiate a SDK and then to configure your security.
Finally, you can make requests to the API by using the SDK.

Considering a fictive API called `contacts` with the following resources:

```
GET /contacts/
GET /contacts/{contactid}
```

It would be called using:

```objective-c
#import "ASKSdk.h"

// create a new SDK
ASKContactsSdk *mySDK = [ASKSdk contactsSdk];

// set up a basic auth
[mySDK.configuration configureBasicFromSecuritySchemeWithUsername:@"your-endpoint-login" andPassword:@"your-endpoint-password"];

// GET /contacts/
ASKResourceContactList *resourceContactList = [mySDK resourceContactList];
[resourceContactList getUsingBlock:^(NSArray *contacts, NSError *error, AFHTTPRequestOperation *operation) {

        if (error) {
            NSLog(@"Oops! %@", error);
            return;
        }

        NSLog(@"%@", contacts);
    }];

// GET /contacts/{contactid}
ASKResourceContact *contactResource = [mySDK resourceContactWithContactid:@"a_contact_id"];
[contactResource getUsingBlock:nil];
```

# Architecture
The SDK is structured as follows:

* `ASKSdk.h` lists the SDK's main header files and provides an entrypoint to all the APIs' SDKs.
* Common provides some general classes not specific to one API SDK
  * Refer to `ASKErrors.h` for the error codes used within the SDK
* One dedicated folder per generated API's SDK

# APIs

This SDK provides access to the following APIs:

## STARTUP API - version: 1.0

No description

Sources' folder: `ASKSTARTUPAPI`

This SDK can be initialized using:

```objective-c
ASKSTARTUPAPISdk *sdk = [ASKSdk sTARTUPAPISdk];
```


# Support of SSL self-signed certificates

If the API server defines an SSL certificate that is not trusted by your app, you need to setup some settings across your application.
This happens, for example, if the SSL certificate is self-signed.

## Update the Info.plist file

When creating an application, an `Info.plist` file is created as well.
You need to add a new rule named `App Transport Security Settings` and add the attribute `Allow Arbitrary loads` with the value `YES` to it.

## Update your SDK settings

Update the SDK configuration by using the method `allowSelfSignedCertificates`:
 
```objective-c 

ASKContactsSdk *mySDK = [ASKSdk contactsSdk];
[mySDK.configuration allowSelfSignedCertificates]; // specify that the application will use a self-signed certificate

```

## Override NSURLRequest (for OAuth2 implicit flow)
When using a webView, for an OAuth2 implicit flow, you need to override `allowsAnyHTTPSCertificateForHost` of `NSURLRequest` such as:
   
```objective-c 

@implementation MYViewController
// ... code of your view controller ...
@end

// override NSURLRequest
@implementation NSURLRequest(DataController)

+(BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host
{
   return YES;
}

@end

```
# OAuth 2.0 with your API

If an OAuth 2.0 security configuration is present, you can retrieve it from the SDK.
Indeed, it has already been initialized in the SDK's configuration (e.g. `ASKContactsConfig.m`).

```objective-c
#import "ASKSdk.h"

// create a new SDK
ASKContactsSdk *mySDK = [ASKSdk contactsSdk];

// retrieve the oauth 2.0 configuration
ASKSecurityConfig *securityConfig = mySDK.configuration.securityConfigs[@"name-of-the-security"];

```
This allows you to complete the `securityConfig` with additional information, according to its OAuth flow, e.g.:

```objective-c
// for example, with this information:
securityConfig.oauth2ClientId = @"my-client-id";
securityConfig.oauth2RedirectURI = @"my-redirect-uri";
securityConfig.oauth2State = @"my-state";
```
Then, you can request the OAuth server to obtain an access token. With this access token, you'll be able to call your API resources.
# OAuth 2.0 with the SDK helpers

The SDK provides helpers for implementing OAuth 2.0 authentication flows. 
The Implicit Grant Flow and the Resource Owner Password Flow are currently supported. 
Please refer to the [OAuth 2.0 documentation](https://tools.ietf.org/html/rfc6749) for an explanation of all the flows.

## Implicit flow

The implicit grant is handled by `ASKOAuth2ImplicitFlowHelper.h`. 

### Usage example

```
ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
securityConfig.oauth2AuthorizationURL = @"http://example.com/api/authorization";
securityConfig.oauth2Scope = @"read,write";
securityConfig.oauth2ClientId = @"my-client-id";
securityConfig.oauth2RedirectURI = @"my-redirect-uri";
securityConfig.oauth2State = @"my-state";

NSString *authorizationUrl = [ASKOAuth2ImplicitFlowHelper getWebViewAuthorizationURLForConfig:securityConfig];
// http://example.com/api/authorization?response_type=token&client-id=my-client-id&redirect_uri=my-redirect-uri&scope=read,write&state=my-state
```
If needed, you can add additional parameters to the authorization URL with this variant:
```
[ASKOAuth2ImplicitFlowHelper getWebViewAuthorizationURLForConfig:securityConfig
                                        andAdditionalParameters:@{ @"another_query_param": @"another_value"}];
```
Then, you'll need to open the authorizationUri in a view (user-agent).
Through this page, the OAuth provider will ask the user (resource owner) to authorize the application.
Once authorized, the user-agent will be redirected to the previously specified *redirect URI*.
Then, in your callback, you will need to use this helper in order to complete the securityConfig with the new information:
```
// viewUri being the current uri of the view, provided by your callback
NSError *error = nil;
[ASKOAuth2ImplicitFlowHelper updateSecurityConfig:securityConfig fromWebViewURL:viewUri error:&error];
if (error) {
    NSLog(@"%@", error);
    return;
}
``` 
If needed, you can retrieve yourself the information from the view URI thanks to the following helper:
```
NSDictionary *keyValues = [ASKOAuth2ImplicitFlowHelper getFragmentKeyValuesFromViewURL:viewUri];
// access_token, state, ...
```
Now, with the updated securityConfig, you can call a resource:
```
AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

[manager.requestSerializer setValue:securityConfig.value // "Bearer <access-token>"
                 forHTTPHeaderField:@"Authorization"];

[manager GET:@"http://example.com/api/resources"
  parameters:nil
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         NSLog(@"%@", responseObject);
     }
     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"%@", error);
     }];
```
Also, you can send the access token as a query parameter:
```
AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

[manager GET:@"http://example.com/api/resources"
  parameters:@{ @"access_token": securityConfig.oauth2AccessToken }
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         NSLog(@"%@", responseObject);
     }
     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"%@", error);
     }];
```

#### Support of SSL self-signed certificates
If your application uses a self-signed certificate, the view used for authentication needs to override `allowsAnyHTTPSCertificateForHost` of `NSURLRequest` such as:
   
```objective-c 

@implementation MYViewController
// ... code of your view controller ...
@end

// override NSURLRequest
@implementation NSURLRequest(DataController)

+(BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host
{
   return YES;
}

@end
```

### CSRF protection
The SDK embeds a protection against Cross-Site Request Forgery (CSRF). 
In compliance with the OAuth specification, you can choose to send a "state" parameter when negotiating a token. 
This state parameter should be returned unchanged by the Authentication server.

The SDK checks this to prevent CSRF. 
If the state parameter doesn't match, an error is given.

## Resource Owner Password flow

The resource owner password flow is handled by `ASKOAuth2PasswordFlowHelper.h`. 

### Usage example

```
ASKSecurityConfig *securityConfig = [ASKSecurityConfig securityConfig];
securityConfig.oauth2TokenURL = @"http://example.com/api/token";
securityConfig.oauth2Scope = @"read,write";
securityConfig.oauth2ClientId = @"my-client-id";
securityConfig.oauth2ClientSecret = @"my-client-secret";
securityConfig.oauth2Username = @"my-username";
securityConfig.oauth2Password = @"my-password";

[ASKOAuth2PasswordFlowHelper fetchAccessAndRefreshTokensForConfig:securityConfig
                                                        andBlock:^(id responseObject, NSError *error, AFHTTPRequestOperation *operation) {
                                                            
                                                            NSLog(@"%@", securityConfig.oauth2AccessToken);
                                                            NSLog(@"%@", securityConfig.oauth2RefreshToken);
                                                        }];
```
Then, you can call the API:
```
AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

[manager.requestSerializer setValue:securityConfig.value // "Bearer <access-token>"
                 forHTTPHeaderField:@"Authorization"];

[manager GET:@"http://example.com/api/resources"
  parameters:nil
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         NSLog(@"%@", responseObject);
     }
     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"%@", error);
     }];
```
Also, you could send the access token as a query parameter:
```
AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

[manager GET:@"http://example.com/api/resources"
  parameters:@{ @"access_token": securityConfig.oauth2AccessToken }
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         NSLog(@"%@", responseObject);
     }
     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         NSLog(@"%@", error);
     }];
```
### Refresh Token

Additionally to the Access Token, the OAuth provider issues a Refresh Token. For this case, the SDK provides some useful helpers.
Expiration information can be accessed once the access token is obtained:
```
NSString *expiresIn = securityConfig.oauth2ExpiresIn;
NSDate *expirationDate = securityConfig.oauth2ExpirationDate;
```
This information can be used to handle automatically the refresh of tokens at two places:

1) *Before* requesting the server, e.g.:

If the expiration date has been reached (`shouldRefreshTokenForSecurityConfig`), 
then you can ask for the refresh of the access token and the refresh token 
with `requestRefreshTokenForConfig`. 

```
AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

if ([ASKOAuth2PasswordFlowHelper shouldRefreshTokenForSecurityConfig:securityConfig]) {
    [ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                     success:^{
                                                         // Access token and refresh token have been refreshed successfully.
                                                         // Hence, you should now request the server.
                                                     }
                                                     failure:^(NSError *error, AFHTTPRequestOperation *operation) {
                                                         // The refresh of tokens has not been achieved.
                                                         // You should handle the occurred error...
                                                     }];    
    return;
}

// [manager GET:...];
// ...
```

2) *After* requesting the server, e.g. on receiving an error from the server:

```
// ...
[manager GET:@"http://example.com/api/resources"
  parameters:nil
     success:^(AFHTTPRequestOperation *operation, id responseObject) {
         NSLog(@"%@", responseObject);
     }
     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [ASKOAuth2PasswordFlowHelper handleRequestError:error
                                      forSecurityConfig:securityConfig
                                           andOperation:operation
                                        andFailureBlock:^(NSError *error, AFHTTPRequestOperation *theOperation){
                                            // The refresh of tokens has not been achieved.
                                            // You should handle the occurred error...
                                        }
                                        andRepeatBlock:^{
                                            // Access token and refresh token have been refreshed successfully.
                                            // Hence, you should now re-request the server...
                                        }];
     }];
```

If the request failed, you can use `handleRequestError`.

First, it will check that it is because of an invalid token.
This check is based on the `401` status code only. 
You can override this check by implementing the block `securityConfig.isAccessTokenExpiredOnRequestError`.    

Then, it will request a new access token and a new refresh token, 
and then execute the `repeatBlock`. 

Note that the automatic refreshing mechanism can be disabled by the following settings:
```
securityConfig.oauth2ShouldHandleRefreshTokenAutomatically = NO;
```
In this case, the refreshing can be done manually by using:
```
[ASKOAuth2PasswordFlowHelper requestRefreshTokenForConfig:securityConfig
                                                 success:^{
                                                     // Access token and refresh token have been refreshed successfully.
                                                     // You can now request the server.
                                                 }
                                                 failure:^(NSError *error, AFHTTPRequestOperation *theOperation){
                                                     NSLog(@"%@", error);
                                                 }];
```

