//
//  HttpContext.m
//  
//
//  Created by Kartik Andalam on 8/31/15.
//  Copyright (c) 2015 APIMatic. All rights reserved.
//

#import "HttpContext.h"

@implementation HttpContext

@synthesize request;

@synthesize response;

@end
