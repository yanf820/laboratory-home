
#import "ErrorSchemaException.h"
@implementation ErrorSchemaException

/**
* TODO: Write general description for this method
*/
@synthesize errorCode;

/**
* TODO: Write general description for this method
*/
@synthesize message;

/**
* TODO: Write general description for this method
*/
@synthesize requestId;

/**
* TODO: Write general description for this method
*/
@synthesize status;

/**
* TODO: Write general description for this method
*/
@synthesize timestamp;


- (ErrorSchemaException*) initWithReason: (NSString*) reason
                                  andContext: (HttpContext*) context
{
    self = [super initWithReason:reason andContext:context];
    return self;
}

- (void) unbox
{
    NSDictionary* data = [APIHelper jsonDeserializeObject: self.context.response.rawBody];
    errorCode = [NSNumber numberWithDouble:[[data objectForKey: @"errorCode"] doubleValue]];
    message = [data objectForKey: @"message"];
    requestId = [data objectForKey: @"requestId"];
    status = [NSNumber numberWithDouble:[[data objectForKey: @"status"] doubleValue]];
    timestamp = [NSNumber numberWithDouble:[[data objectForKey: @"timestamp"] doubleValue]];
}
@end